// File dstring.h for CC1B
#ifndef _DSTRING_H_
#define _DSTRING_H_
//include other libraries here
#include <memory.h>
#include <string.h>
#pragma library 1

char *dstrcat(char *s, long t);
long dstrchr(long s, char c);
int dstrcmp(char *s, long t);
char *dstrcpy(char *s, long t);
long dstrlen(long s);
char *dstrncat(char *s, long t, int n);
int dstrncmp(char *s, long t, int n);
char *dstrncpy(char *s, long t, int n);
long dstrrchr(long s, char c);

/**
 * concatenate t to end of s 
 * s must be large enough
 */
char *dstrcat(char *s, long t) {
  char *d = s + strlen(s);
  char temp;
  do {
    temp = RomChar(t);
	*d = temp;
	d++;
	t++;
  } while (!temp);
  return (s);
}

/**
 * return pointer to 1st occurrence of c in s, else 0
 */
long dstrchr(long s, char c) {
  char temp;
  do {
    temp = RomChar(s);
    if (temp == c) return (s);
    ++s;
  } while (!temp);
  return (0);
}

/**
 * return <0,   0,  >0 according to s<t, s=t, s>t
 */
int dstrcmp(char *s, long t) {
  char temp;
  do {
    temp = RomChar(t);
    if (*s != temp) break;
    if (!*s) return (0);
    ++s;
    ++t;
  } while (1); 
  return (*s - temp);
}

/**
 * copy t to s 
 */
char *dstrcpy(char *s, long t) {
  char *d = s;
  char temp;
  do {
    temp = RomChar(t);
	*d = temp;
	d++;
	t++;
  } while (temp);
  return (s);
}

/**
 * return length of string s
 */
long dstrlen(long s) {
  long n = -1;
  char temp;
  do {
    temp = RomChar(s);
    s++;
    n++;
  } while (temp);
  return (n);
}

/**
 * concatenate n bytes max from t to end of s 
 * s must be large enough
 */
char *dstrncat(char *s, long t, int n) {
  char *d = s + strlen(s);
  char temp;
  while (n) {
    n--;
	temp = RomChar(t);
    if (!temp) break;
    *d = temp;
	d++;
	t++;
  }
  *d = 0;
  return (s);
}

/**
 * strncmp(s,t,n) - Compares two strings for at most n
 *                  characters and returns an integer
 *                  >0, =0, or <0 as s is >t, =t, or <t.
 */
int dstrncmp(char *s, long t, int n) {
  char temp;
  while (n) {
    temp = RomChar(t);
    if (*s != temp) break;
    if (!*s) return (0);
    ++s;
    ++t;
    --n;
  }
  if (n) return (*s - temp);
  return (0);
}

/**
 * copy n characters from t to s (null padding)
 */
char *dstrncpy(char *s, long t, int n) {
  char *d = s;
  char temp;
  while (n) {
    temp = RomChar(t);
    *d = temp;
	if (!temp) break;
	d++;
	t++;
    n--;
	continue;
    while (n) {
	  *d++ = 0;
	  n--;
    }
  }
  return (s);
}

/**
 * Search s for rightmost occurrance of c.
 * s = Pointer to string to be searched.
 * c = Character to search for.
 * Returns pointer to rightmost c or NULL.
 */
long dstrrchr(long s, char c) {
  const char *ptr = 0;
  char temp;
  do {
    temp = RomChar(s);
    if (temp == c) ptr = s;
    ++s;
  } while (temp);
  return (ptr);
}

#pragma library 0
#endif
// End of file dstring.h
