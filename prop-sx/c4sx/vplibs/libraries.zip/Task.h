// File Task.h for CC1B
#ifndef _TASK_H_
#define _TASK_H_
//include other libraries here
#pragma library 1

/*
The taskswitching mechanism is NOT multitasking. It allows subroutines to run automatically at specified intervals.
The interrupt routine monitors when it is time to run a task. Then a contextswitch is done, so that after the interrupt
routine exits, a task routine is executed, rather than the mainlevel code that was interrupted. The interrupts remain
active while the task runs. Only after the task exits, will the mainlevel code continue (after another contextswitch).
It is therefore imperative that a task never blocks or waits for an event. If it must wait, let it set a flag and return.
The next time it runs, it can check the flag.
The SX secret instructions are used to perform the contextswitch.

For clarity, I defined TASK which equals void. It allows you to use
TASK myTask() {
}
Note that task routines appear to CC1B as part of the interrupt call tree, although the task routines
themselves execute as mainlevel code. You should never call a TASK subroutine from normal mainlevel code.

Here are some guide 'rules' to determine the correct tasks parameters.
The goal is to LET EACH TASK START ON TIME.
In the following, N is the number of tasks, M is the number of mainlevel taskticks (>= 0).

By using M>0 there is a guaranteed minimum CPU cycles reserved for mainlevel code.
This percentage is (M/(M+N) )*100%

The roundtrip cycle equals N+M.
Since there are N tasks running, the task interval value must be a multiple of N+M: interval = K*(N+M) where K>=1.
Each task must return with 1 tasktick. If you find that a task does not return within 1 tasktick, either split up the
task in smaller pieces (state machine) or increase the TASKTICK value.

   All tasks must have an interval equal to K*(N+M) and must return within 1 tasktick and should
   start 1 tasktick apart. This ensures tasks do not overlap and are evenly spaced in time and start on time.

You are not bound by the above rule. You can set the interval to any non-zero value (1-255) but then it may
happen that tasks are at some point scheduled for the same time and then the tasks are not deterministic.
Tasks scheduled for the same time are simply executed after each other without returning to the mainlevel
code inbetween.

If K>1 then a task does not use all its timeslices. Unused timeslices are not available to other
tasks but are used for mainloopcode. If taskcode takes too much time, a statemachine can be
used to make a task return in time. If a task should run at a lower rate than set by its interval
parameter, the task can decrement a counter and return immediately if it has not reached 0.

Since the interval parameter is an 8bit value, the highest K calculates from K*(N+M) = 255. This yields Kmax = int(255/(N+M))
INTPERIOD determines the interrupt tick: isrtick = INTPERIOD/CPUFREQ
TASKTICK determines the tasktick: tasktick = TASKTICK*isrtick
The maximum value for TASKTICK is 65279

Example: suppose you want to run a task 1000 times per second, with given CPUFREQ=20_000_000 and INTPERIOD=217
isrtick = INTPERIOD/CPUFREQ = 217/20_000_000 = 10.85 uSec
tasktick = TASKTICK * 10.85 uSec = (1/1000) Sec = 1000 uSec
TASKTICK = 1000/10.85 = 92 with interval N+M
But you can also select TASKTICK = 46 with interval = 2*(N+M)
or TASKTICK = 23 with interval = 4*(N+M)
Normally the task that must run at the highest rate determines TASKTICK
and interval is adjusted for tasks that run at a lower rate.
*/

#ifndef TASKS
#error TASKS (1-5) needs to be defined before including <Task.h>
#else
#if (TASKS < 1) || (TASKS > 5)
#error TASKS needs to be in range 1 to 5
#endif
#endif

#ifndef TASKFACTOR
#define TASKFACTOR 1
#endif

#ifndef TASKLIST
#error TASKLIST needs to be defined before including <Task.h>
#else
#if (16 - (TASKLIST & 0x0F)) < (3*TASKS+1)
#error TASKLIST value too high, TaskList array not in single bank
#endif
#endif
 
#define TASK void
#define TASKSTART 0x80
#define TASKRUNONCE 0x40

char TaskList[3*TASKS+1] @TASKLIST;
  char TaskId[TASKS] @TaskList[0]; //b7=enable, b6=runonce b5-b0: taskid
  char TaskInterval[TASKS] @TaskList[TASKS];
  char TaskRunTick[TASKS] @TaskList[2*TASKS];
  char TaskToRun @TaskList[3*TASKS];

#define TASKKERNEL 0xF0
char TaskCountLSB @0xF0; //16bits divisor to keep track when contextswitch must occur
char TaskCountMSB @0xF1;
char TaskDelay @0xF2; //number of taskticks to wait before task runs, or number of taskticks passed while task runs
char TaskSuspendTicks @0xF3; //number of taskticks that a task can suspend itself
char TaskFlags @0xF4; //lownib increments every tasktick until b4 set
  bit TaskPauseDone @TaskFlags.4; //set if TaskPause completed
  bit TaskRunning @TaskFlags.5; //set if task code is currently running
  bit TaskFinished @TaskFlags.6; //set if task code finished
  bit TaskEnabled @TaskFlags.7; //set if tasks are allowed to run
char Task_W @0xFA; //mainlevel code save area
char Task_M @0xFB;
char Task_ST @0xFC;
char Task_FSR @0xFD;
char Task_PCL @0xFE; // mainlevel code return address
char Task_PCH @0xFF;

#pragma cdata.TASKDATA
#if TASKS == 1
#pragma cdata[] = 0
#pragma cdata[] = TASKS*TASKFACTOR
#pragma cdata[] = 1+(0*TASKFACTOR)
#elif TASKS == 2
#pragma cdata[] = 0,1
#pragma cdata[] = TASKS*TASKFACTOR,TASKS*TASKFACTOR
#pragma cdata[] = 1+(0*TASKFACTOR),1+(1*TASKFACTOR)
#elif TASKS == 3
#pragma cdata[] = 0,1,2
#pragma cdata[] = TASKS*TASKFACTOR,TASKS*TASKFACTOR,TASKS*TASKFACTOR
#pragma cdata[] = 1+(0*TASKFACTOR),1+(1*TASKFACTOR),1+(2*TASKFACTOR)
#elif TASKS == 4
#pragma cdata[] = 0,1,2,3
#pragma cdata[] = TASKS*TASKFACTOR,TASKS*TASKFACTOR,TASKS*TASKFACTOR,TASKS*TASKFACTOR
#pragma cdata[] = 1+(0*TASKFACTOR),1+(1*TASKFACTOR),1+(2*TASKFACTOR),1+(3*TASKFACTOR)
#elif TASKS == 5
#pragma cdata[] = 0,1,2,3,4
#pragma cdata[] = TASKS*TASKFACTOR,TASKS*TASKFACTOR,TASKS*TASKFACTOR,TASKS*TASKFACTOR,TASKS*TASKFACTOR
#pragma cdata[] = 1+(0*TASKFACTOR),1+(1*TASKFACTOR),1+(2*TASKFACTOR),1+(3*TASKFACTOR),1+(4*TASKFACTOR)
#endif
#pragma cdata[] = 0
#pragma cdata[] = 1,1,0,0,0x10

/**
 * Initialize task scheduler.
 * This function is to be called from mainlevel code.
 * It must be called before any of the other task functions.
 */
void TaskInit() {
  RomCopy(TaskList,TASKDATA,3*TASKS+1);
  RomCopy(TASKKERNEL,TASKDATA+(3*TASKS+1),5);
}

/**
 * Enable the task scheduler.
 * Tasks are allowed to run.
 */
void TaskEnable() {
  TaskEnabled = 1;
}

/**
 * Disable the task scheduler.
 * No tasks will run.
 */
void TaskDisable() {
  TaskEnabled = 0;
}

/**
 * Set task from mainlevel code.
 * The task parameters are setup in the TaskList.
 * This function is to be called from mainlevel code.
 *
 * @param slot Index in TaskList
 * @param taskid Identifier for task subroutine (may be ORed with TASKSTART and/or TASKRUNONCE)
 * @param interval Specifies in taskticks (>=1) how frequently the task runs
 *                               Do not use value 0
 */
void TaskSet(char slot, char taskid, char interval) {
  char flags = TaskFlags & 0x80; //get current enable state
  TaskEnabled = 0; //disable tasks
  _MainTemp = interval;
  TaskInterval[slot] = _MainTemp;
  _MainTemp = taskid;
  TaskId[slot] = _MainTemp;
  TaskFlags |= flags; //restore enable state
}

/**
 * Set task from task subroutine.
 * The task parameters are setup in the TaskList.
 * This function is to be called from a task subroutine.
 *
 * @param slot Index in TaskList
 * @param taskid Identifier for task subroutine (may be ORed with TASKSTART and/or TASKRUNONCE)
 * @param interval Specifies in taskticks (>=1) how frequently the task runs
 *                               Do not use value 0
 */
void TaskChange(char slot, char taskid, char interval) {
  _TaskTemp = interval;
  TaskInterval[slot] = _TaskTemp;
  _TaskTemp = taskid;
  TaskId[slot] = _TaskTemp;
}

/**
 * Get slot for running task.
 * This function is to be called from a task subroutine.
 *
 * @return slot for running task
 */
char TaskRun() {
  return TaskToRun;
}

/**
 * Get slot for specified task.
 * This function is to be called from mainlevel code.
 *
 * @param taskid Task identifier for task subroutine
 * @return slot for specified task, or 0xFF if slot not found (eg. task not set)
 */
char TaskSlot(char taskid) {
  char i;
  taskid &= 0x3F; //mask off TASKSTART and TASKRUNONCE bits
  for (i=0; i<TASKS; i++) {
    if ((TaskId[i] & 0x3F) == taskid) return i;
  }
  return 0xFF;
}

/**
 * Get the current task timer value.
 *
 * @return Current task timer value
 */
char TaskTimer() {
#pragma update_FSR 0
  FSR = TaskRunTick;
  W = TaskToRun;
  FSR += W;
  W = INDF;         // W = TaskRunTick[TaskToRun]
  FSR = 0;
  FSR = ~FSR;       // FSR =0xFF (eg. bank TASKKERNEL)
  if (TaskRunning) {
    // TaskDelay holds passed ticks for current task -> runtime = TaskRunTick[TaskToRun] + TaskDelay
    W += TaskDelay; // W = TaskRunTick[TaskTorun] + TaskDelay
  }
  else {
    // TaskDelay holds ticks that must pass before next task runs -> runtime= TaskRunTick[TaskToRun] - TaskDelay
	W = TaskDelay-W; // W = TaskDelay - TaskRunTick[TaskToRun]
    W = ~W;          // W = ~(TaskDelay - TaskRunTick[TaskToRun])
    FSR = 0;
    FSR++;           // FSR = 1
    W += FSR;        // W = ~(TaskDelay - TaskRunTick[TaskToRun]) + 1 = TaskRunTick[TaskToRun] - TaskDelay
  }
#pragma update_FSR 1
  return W;
}

/**
 * Pause for a number of taskticks.
 * This function is to be called from mainlevel code.
 *
 * @param W Number of taskticks to pause (1-255)
 */
void TaskPauseLong(char ticks) {
  char start = TaskTimer();
  char stop = start+ticks;
  bit p1,p2;
  do {
    char current = TaskTimer();
    p1 = (current >= stop);
    p2 = (current < start);
    if (start < stop) {
      p1 |= p2;
    }
    else {
      p1 &= p2;
    }
  } while (!p1);
}

/**
 * Pause for a number of taskticks.
 *
 * @param W Number of taskticks to pause (1-15)
 */
void TaskPause(char W) {
  if (W) {
    W = ~W;
    W &= 0x0F;
    TaskFlags |= W;
	TaskFlags++;
    TaskPauseDone = 0;
    while (!TaskPauseDone) ;
  }
}

/**
 * Start a task.
 *
 * @param W Index in TaskList
 */
void TaskStart(char W) {
  FSR = W;
  FSR += TaskId;
  INDF.7 = 1;
}

/**
 * Stop a task.
 *
 * @param W Index in TaskList
 */
void TaskStop(char W) {
  FSR = W;
  FSR += TaskId;
  INDF.7 = 0;
}

/**
 * Reschedule a task.
 * This function is to be called from a task subroutine.
 *
 * @param W Number of taskticks after which the task runs again once it is finished
 *                     A non-zero value will reschedule the task using that value instead of the task interval value.
 *                     The interval value however is not overwritten. This allows a task to run more often if required.
 */
void TaskReschedule(char W) {
  TaskSuspendTicks = W;
}

/**
 * Get task status.
 *
 * @param W Index in TaskList
 * @return Status byte
 *                b7 set if task enabled
 *                b6 set if task set as runonce
 *                b5-b0: task id (0-63)
 */
char TaskStatus(char W) {
  FSR = W;
  FSR += TaskId;
  W = INDF;
  return W;
}

#pragma library 0
extern void TaskSwitch(char W); //application supplied function

/**
 * The mainlevel part of the task scheduler
 * It executes outside the isr, but is only called from the isr.
 * This routine calls the function TaskSwitch that must be supplied by the application.
 * It is important to realize that this function in effect interrupts the mainlevel code.
 */
void TaskSchedule() {
  char index,runtime,delay;
  // start task code (interrupts mainlevel code, executes outside isr)
  nop(); //in case interrupt occured in middle of skip instruction
  FSR = TASKKERNEL;
  W = MODE; //save m
  Task_M = W;
Task_run:
  TaskSuspendTicks = 0; //may be set by task using TaskReschedule()
  index = TaskId[TaskToRun];
  if (index.7 == 1) { //only run task if enabled
    TaskSwitch(index);
	if (index.6) TaskId[TaskToRun].7 = 0; //if runonce, stop task after run
  }
  //reschedule current task
  runtime = TaskRunTick[TaskToRun]; //current time
  W = TaskSuspendTicks;
  if (!W) {
	W = TaskInterval[TaskToRun];
  }
  _TaskTemp = W + runtime;
  TaskRunTick[TaskToRun] = _TaskTemp;
  //find next task to run
  delay = 255;
  for (index=0; index<TASKS; index++) {
	W = TaskRunTick[index];
    _TaskTemp = W - runtime;
    if (_TaskTemp < delay) {
      delay = _TaskTemp;
      TaskToRun = index; //next time that TaskSchedule runs, the task in TaskToRun is called
	}
  }
  if (delay <= TaskDelay) { //next task was scheduled for same time, or for later time but taskticks are missed so it must run now
    TaskDelay = TaskDelay - delay;
    goto Task_run; //no contextswitch, but immediately run the next task
  }
  else {
    TaskDelay = delay - TaskDelay; //next task scheduled for later time
  }
  // exit task code (contextswitch to run mainlevel code)
#pragma update_FSR 0
  FSR = TASKKERNEL;
  W = Task_M; //restore m
  MODE = W;
  W = 25; //check if rtcc will overrun when doing contextswitch directly
  //-------------------------
  W += RTCC; // 21+4 cycles are required to do context switch now (leaves new rtcc @mainlevel <= $FC)
  TaskFinished = 1;
  if (Carry) { //carry clear if enough cycles left to do context switch now
Task_exit_wait:
    goto Task_exit_wait; //wait for interrupt to do contextswitch
  }
  //task has finished, restore registers from outside isr
  W = Task_W; //restore w
#asm
  DW 0x48 ;PUSHW ;1
#endasm
  W = Task_ST; //restore st
#asm
  DW 0x49 ;PUSHST ;1
#endasm
  W = Task_FSR; //restore fsr
#asm
  DW 0x4A ;PUSHFSR ;1
#endasm
  W = Task_PCH; //restore pc
  MODE = W;
  W = Task_PCL;
#asm
  DW 0x4B ;PUSHPC ;1
#endasm
  W = Task_M; //restore m
  MODE = W;
  TaskRunning = 0;
  TaskFinished = 0;
#asm
  DW 0x0E ;RETI ;3 //continue to execute mainlevel code (leaving rtcc <= $FC)
#endasm
#pragma update_FSR 1
}

/**
 * The interrupt part of the task scheduler
 * It must run at the end of the interrupt routine.
 * If a task must run, it redirects program control to TaskSchedule().
 */
#define Task_ISR \
{ \
  FSR = TASKKERNEL; \
  if (0) TaskSchedule(); \
#pragma update_FSR 0 \
  TaskCountLSB--; \
  if (!Zero_) goto Task_contextswitch; \
#if TASKTICK > 255 \
  TaskCountMSB--; \
  if (!Zero_) goto Task_contextswitch; \
  TaskCountMSB = (TASKTICK+256) >> 8; \
#endif \
  TaskCountLSB = (TASKTICK+256) & 0xFF; \
  if (!TaskFlags.4) TaskFlags++; \
  TaskDelay++; \
  if (TaskRunning) goto Task_contextswitch; \
  TaskDelay--; \
  if (!Zero_) { \
    TaskDelay--; \
  } \
  if (TaskDelay) goto Task_contextswitch; \
  if (!TaskEnabled) goto Task_contextswitch; \
  TaskRunning = 1; \
#asm \
  DW 0x4C ;POPW \
#endasm \
  Task_W = W; \
#asm \
  DW 0x4D ;POPST \
#endasm \
  Task_ST = W; \
#asm \
  DW 0x4E ;POPFSR \
#endasm \
  Task_FSR = W; \
#asm \
  DW 0x4F ;POPPC \
#endasm \
  Task_PCL = W; \
  W = MODE; \
  Task_PCH = W; \
  W = 0; \
  MODE = W; \
  W = 0x02; \
#asm \
  DW 0x4B ;PUSHPC ;retiw will force contextswitch to run TaskSchedule() \
#endasm \
  goto Task_exit; \
Task_contextswitch: \
  if (!TaskFinished) goto Task_exit; \
  W = Task_W; \
#asm \
  DW 0x48 ;PUSHW \
#endasm \
  W = Task_ST; \
#asm \
  DW 0x49 ;PUSHST \
#endasm \
  W = Task_FSR; \
#asm \
  DW 0x4A ;PUSHFSR \
#endasm \
  W = Task_PCH; \
  MODE = W; \
  W = Task_PCL; \
#asm \
  DW 0x4B ;PUSHPC ;retiw will force contextswitch to run mainlevel code \
#endasm \
  TaskRunning = 0; \
  TaskFinished = 0; \
Task_exit: \
#pragma update_FSR 1 \
}

#endif
// End of file Task.h
