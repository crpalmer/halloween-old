// File objStack.h for CC1B
#ifndef _OBJSTACK_H_
#define _OBJSTACK_H_
//include other libraries here
#include <memory.h>
#pragma library 1

/**
 * This library provides a stack object that can store up to 15 bytes. The stack must reside in a single rambank.
 * The functions are writton so that they can be used in any call tree (interrupt, mainlevel and tasklevel)
 *
 * Any char array can be initialized to be a stack
 * char s[12];
 * _MainTemp = 8; \\size of the stack must be stored in a global ram location
 * objStack_init(s,_MainTemp);
 * This declares s[0]-s[7] to be a stack that has a total size of 8 bytes (7 bytes data + 1 byte overhead)
 *
 * Values are stored into the stack using function objStack_push.
 * It requires the value to be pushed to be stored in a global ram location before calling.
 * if (!objStack_full(s)) {
 *   _MainTemp = value; //value to push must be in a global ram location
 *   objStack_push(s,_MainTemp);
 * }
 * The function can be used in any call tree by using either _MainTemp, _IsrTemp or _TaskTemp as the global ram location.
 *
 * Values are retrieved from the stack using function objStack_pop.
 * This function returns true if the value is retrieved, or false if the stack is empty
 * The retrieved value is returned in W
 * if (objStack_pop(S1) {
 *   value = W;
 * }
 *
 * The stack can be cleared by using the function objStack_clear(s)
 * To test if the stack is empty, use objStack_isEmpty(s)
 * To test if the stack is full, use objStack_isFull(s)
 */

//stack buffer layout
//
// +----+----+
// |size| num|  size = number of databytes in stack buffer, num = number of values on stack 
// +----+----+
// | d a t a |
// | d a t a |

/** Initialize a stack
 * How to use:
 *   char s[12];
 *   _MainTemp = 12; //size of stack must be in a global ram location
 *   objStack_init(s,_MainTemp);
 *
 * @param stack Physical address of queue
 * @param size Size of the stack. The size MUST have been stored in a global ram location (0x00-0x0F)
 */
#define objStack_init(stack,size) \
{ \
  W = stack; \
#pragma update_FSR 0 \
  FSR = W; \
  size--; \
  W = swap(size); \
  INDF = W; \
#pragma update_FSR 1 \
}

/** Check if stack empty
 *
 * @param W Stack address
 * @return True if stack empty, false if not empty
 */
bit objStack_isEmpty(char W) {
#pragma update_FSR 0
  FSR = W;
  W = 0x0F;
  W &= INDF; //extract num
#pragma update_FSR 1
  return Zero_;
}

/** Check if stack full
 *
 * @param W Stack address
 * @return True if stack full, false if not full
 */
bit objStack_isFull(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF);
  W ^= INDF; //xor num with size
#pragma update_FSR 1
  return Zero_;
}

/** Clear stack
 * @param W Stack address
 */
void objStack_clear(char W) {
#pragma update_FSR 0
  FSR = W;
  W = 0xF0;
  INDF &= W;  //clear num
#pragma update_FSR 1
}

/** Get number of stored bytes on stack
 *
 * @param W Stack address
 * @return number of stored bytes (0 to stacksize-1)
 */
char objStack_length(char W) {
#pragma update_FSR 0
  FSR = W;
  W = INDF; //get num in lownib
  W &= 0x0F;
#pragma update_FSR 1
  return W;
}

/** Get capacity of stack
 *
 * @param W Stack address
 * @return capacity of stack (maximum 15)
 */
char objStack_capacity(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF); //get size in lownib
  W &= 0x0F;
#pragma update_FSR 1
  return W;
}

/** Get size of stack
 *
 * @param W Stack address
 * @return size of stack (maximum 16)
 */
char objStack_size(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF); //get size in lownib
  W &= 0x0F;
  FSR = 0;
  FSR.0 = 1;  //FSR=1
  W += FSR; //get total stack size
#pragma update_FSR 1
  return W;
}

/** Get number of free bytes in stack
 *
 * @param W Stack address
 * @return number of free bytes (0 to stacksize-1)
 */
char objStack_free(char W) {
#pragma update_FSR 0              //example:
  FSR = W;                        // INDF = 0101_0010 = size_num  size-num = 5-2=3
  W = swap(INDF); //get size in lownib         // W       = 0010_0101
  W = INDF - W;                   // W       = 0010_1101
  W &= 0x0F;                      // W       = 0000_1101  W=13
  FSR = 0;                        // FSR    = 0
  FSR.4 = 1;                      // FSR    = 16
  W = FSR - W;                    // W       = 16-13 = 3
#pragma update_FSR 1
  return W;
}

/** Push value onto stack
 * How to use:
 * if (!objStack_isFull(s)) {
 *   _MainTemp = value; //value to enqueu must be in a global ram location
 *   objStack_push(s,_MainTemp);
 * }
 *
 * @param stack Stack address
 * @param value Value to write. The value MUST have been stored in a global ram location (0x00-0x0F)
 */
#define objQueue_enqueue(stack,value) \
{ \
  FSR = _objStack_pushAddress(stack); \
  INDF = value; \
}

/** INTERNAL FUNCTION: Check if a stack can accept a new value and adjust pointers if so.
 * This function should not be called directly, but only from the macro objStack_push.
 * This function adjusts the stack's num field if the stack is not full.
 * So if the stack is not full, a new value MUST be stored onto the stack.
 *
 * @param W Stack address
 * @return push address (if stack was not full)
 */
char _objStack_pushAddress(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF); //load size+num
  W ^= INDF; //xor size with num
  if (!Zero_) {
    INDF++; //inc num
    W = INDF; //get num in lownib
	W &= 0x0F;
    FSR++; //point to stack data begin
    W += FSR; //top of stack position
  }
#pragma update_FSR 1
  return W;
}

/** Pop value from stack
 * How to use:
 * if (!objStack_isEmpty(s)) {
 *   value = objStack_pop(s);
 * }
 *
 * @param W Stack address
 * @return Value from stack (if stack was not empty)
 */
char objStack_pop(char W) {
#pragma update_FSR 0
  FSR = W;
  W = INDF; //load size+num
  W &= 0x0F; //test num
  if (!Zero_) {
    INDF--; //dec num
    W = INDF; //get num in lownib
    W &= 0x0F;
    FSR++; //point to stack data begin
    FSR += W; //top of stack position
    W = INDF; //get value
  }
#pragma update_FSR 1
  return W;
}

#pragma library 0
#endif
// End of file objStack.h
