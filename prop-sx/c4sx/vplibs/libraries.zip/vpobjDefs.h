// File vpobjDefs.h for CC1B
#ifndef _VPOBJDEFS_H_
#define _VPOBJDEFS_H_
//include other libraries here
#pragma library 1

// Setup option register. 
//---------------------------------------------------------------------------------

#define RTCC_ON 0b10000000	//;Enables RTCC at address $01 (RTW hi)
					        //;*WREG at address $01 (RTW lo) by default
#define RTCC_ID	0b01000000	//;Disables RTCC edge interrupt (RTE_IE hi)
					        //;*RTCC edge interrupt (RTE_IE lo) enabled by default
#define RTCC_INC_EXT 0b00100000	//;Sets RTCC increment on RTCC pin transition (RTS hi)
					            //;*RTCC increment on internal instruction (RTS lo) is default
#define RTCC_FE	0b00010000	//;Sets RTCC to increment on falling edge (RTE_ES hi)
					        //;*RTCC to increment on rising edge (RTE_ES lo) is default
#define RTCC_PS_ON	0b00000000	//;Assigns prescaler to RTCC (PSA lo)
#define RTCC_PS_OFF	0b00001000	//;Assigns prescaler to WDT (PSA hi)
#define PS_000	0b00000000	//;RTCC = 1:2, WDT = 1:1
#define PS_001	0b00000001	//;RTCC = 1:4, WDT = 1:2
#define PS_010	0b00000010	//;RTCC = 1:8, WDT = 1:4
#define PS_011	0b00000011	//;RTCC = 1:16, WDT = 1:8
#define PS_100	0b00000100	//;RTCC = 1:32, WDT = 1:16
#define PS_101	0b00000101	//;RTCC = 1:64, WDT = 1:32
#define PS_110	0b00000110	//;RTCC = 1:128, WDT = 1:64
#define PS_111	0b00000111	//;RTCC = 1:256, WDT = 1:128

#define PORT_RA     0x05
#define PORTPIN_RA  0x05FF
#define PORTPIN_RA0 0x0501
#define PORTPIN_RA1 0x0502
#define PORTPIN_RA2 0x0504
#define PORTPIN_RA3 0x0508

#if defined _CHIP_SX52_
#define PORTPIN_RA4 0x0510
#define PORTPIN_RA5 0x0520
#define PORTPIN_RA6 0x0540
#define PORTPIN_RA7 0x0580
#endif

#define PORT_RB     0x06
#define PORTPIN_RB  0x06FF
#define PORTPIN_RB0 0x0601
#define PORTPIN_RB1 0x0602
#define PORTPIN_RB2 0x0604
#define PORTPIN_RB3 0x0608
#define PORTPIN_RB4 0x0610
#define PORTPIN_RB5 0x0620
#define PORTPIN_RB6 0x0640
#define PORTPIN_RB7 0x0680

#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_
#define PORT_RC     0x07
#define PORTPIN_RC  0x07FF
#define PORTPIN_RC0 0x0701
#define PORTPIN_RC1 0x0702
#define PORTPIN_RC2 0x0704
#define PORTPIN_RC3 0x0708
#define PORTPIN_RC4 0x0710
#define PORTPIN_RC5 0x0720
#define PORTPIN_RC6 0x0740
#define PORTPIN_RC7 0x0780
#endif

#if defined _CHIP_SX48_ || defined _CHIP_SX52_
#define PORT_RD     0x08
#define PORTPIN_RD  0x08FF
#define PORTPIN_RD0 0x0801
#define PORTPIN_RD1 0x0802
#define PORTPIN_RD2 0x0804
#define PORTPIN_RD3 0x0808
#define PORTPIN_RD4 0x0810
#define PORTPIN_RD5 0x0820
#define PORTPIN_RD6 0x0840
#define PORTPIN_RD7 0x0880
#define PORT_RE     0x09
#define PORTPIN_RE  0x09FF
#define PORTPIN_RE0 0x0901
#define PORTPIN_RE1 0x0902
#define PORTPIN_RE2 0x0904
#define PORTPIN_RE3 0x0908
#define PORTPIN_RE4 0x0910
#define PORTPIN_RE5 0x0920
#define PORTPIN_RE6 0x0940
#define PORTPIN_RE7 0x0980
#endif

#define PORTPIN_INV	0x1000	//invert, OR with PORTPIN value
#define PORTPIN_OC	0x2000	//opencollector, OR with PORTPIN value

//serial data formats
#define E71		0b00001110		//even parity, 7 databits, 1 stopbit , 1 startbit, 10 bits total
#define E72		0b00001111		//even parity, 7 databits, 2 stopbit , 1 startbit, 11 bits total
#define E81		0b00001011		//even parity, 8 databits, 1 stopbit , 1 startbit, 11 bits total
#define O71		0b00010110		//odd  parity, 7 databits, 1 stopbit , 1 startbit, 10 bits total
#define O72		0b00010111		//odd  parity, 7 databits, 2 stopbit , 1 startbit, 11 bits total
#define O81		0b00010011		//odd  parity, 8 databits, 1 stopbit , 1 startbit, 11 bits total
#define N71		0b00000101		//no   parity, 7 databits, 1 stopbit , 1 startbit,  9 bits total 
#define N72		0b00000110		//no   parity, 7 databits, 2 stopbit , 1 startbit, 10 bits total 
#define N81		0b00000010		//no   parity, 8 databits, 1 stopbit , 1 startbit, 10 bits total
#define N82		0b00000011		//no   parity, 8 databits, 2 stopbit , 1 startbit, 11 bits total

#define VP_UNINSTALLED 0
#define VP_TIMER16 1
#define VP_UARTRX 2
#define VP_UARTTX 3

//pin configuration after vpInstall _ after vpUninstall (if b2[b6] set then b0[b4]=LOW/HIGH, b1[5]=OUTPUT/INPUT)
#define LEAVE_LEAVE            0b00000000  //b2 clear: LEAVE = leave pin
#define LEAVE_LOWOUTPUT        0b00000100  //b2 set, b0 clear, b1 clear: LOWOUTPUT = latch 0, direction 0
#define LEAVE_HIGHOUTPUT       0b00000101  //b2 set, b0 set, b1 clear: HIGHOUTPUT = latch 1, direction 0
#define LEAVE_LOWINPUT         0b00000110  //b2 set, b0 clear, b1 set: LOWINPUT = latch 0, direction 1
#define LEAVE_HIGHINPUT        0b00000111  //b2 set, b0 set, b1 set: HIGHINPUT = latch 1, direction 1
#define LOWOUTPUT_LEAVE        0b01000000
#define LOWOUTPUT_LOWOUTPUT    0b01000100
#define LOWOUTPIT_HIGHOUTPUT   0b01000101
#define LOWOUTPUT_LOWINPUT     0b01000110
#define LOWOUTPUT_HIGHINPUT    0b01000111
#define HIGHOUTPUT_LEAVE       0b01010000
#define HIGHOUTPUT_LOWOUTPUT   0b01010100
#define HIGHOUTPUT_HIGHOUTPUT  0b01010101
#define HIGHOUTPUT_LOWINPUT    0b01010110
#define HIGHOUTPUT_HIGHINPUT   0b01010111
#define LOWINPUT_LEAVE         0b01100000
#define LOWINPUT_LOWOUTPUT     0b01100100
#define LOWINPUT_HIGHOUTPUT    0b01100101
#define LOWINPUT_LOWINPUT      0b01100110
#define LOWINPUT_HIGHINPUT     0b01100111
#define HIGHINPUT_LEAVE        0b01110000
#define HIGHINPUT_LOWOUTPUT    0b01110100
#define HIGHINPUT_HIGHOUTPUT   0b01110101
#define HIGHINPUT_LOWINPUT     0b01110110
#define HIGHINPUT_HIGHINPUT    0b01110111

//;-----------------------------------------------------------------------------------------
//; uart calculations (also sets intperiod)
//;-----------------------------------------------------------------------------------------
#ifndef MAXBAUD
#define MAXBAUD 115200
#endif
#if MAXBAUD < 1200
#undef MAXBAUD
#define MAXBAUD 1200
#endif
//;calculate uartfs
#define uartfs MAXBAUD*2  //2x oversampling at maxbaud
#if uartfs < (CPUFREQ/240)   //limit int_period to 240
#undef uartfs
#define uartfs (CPUFREQ/240)
#endif
//;Calculations are for no RTCC prescaler
#if uartfs <= 3600
#undef uartfs
#define uartfs 3600
#elif uartfs <= 7200
#undef uartfs
#define uartfs 7200
#elif uartfs <= 14400
#undef uartfs
#define uartfs 14400
#elif uartfs <= 28800
#undef uartfs
#define uartfs 28800
#elif uartfs <= 57600
#undef uartfs
#define uartfs 57600
#elif uartfs <= 115200
#undef uartfs
#define uartfs 115200
#elif uartfs <= 230400
#undef uartfs
#define uartfs 230400
#elif uartfs <= 460800
#undef uartfs
#define uartfs 460800
#else
#undef uartfs
#define uartfs 921600
#endif

#ifndef INTPERIOD
#define INTPERIOD  ((2*CPUFREQ/uartfs)+1)/2	//int_period = int(cpufreq/uartfs + 0.5)
#endif

#define MSCOUNT	((2*1000*(CPUFREQ/1000000)/INTPERIOD)+1)/2	//isr cycles for 1 msec
//			;50MHz -> 230, 20MHz -> 115, 10MHz -> 57, 4MHz -> 29
#define USCOUNT	((2*250*(CPUFREQ/1000000)/INTPERIOD)+1)/2	//isr cycles for 250 usec
//			;50MHz -> 58, 20MHz -> 29, 10MHz -> 14, 4MHz -> 7

/*
Baud divide calculation
*****************************************************************************************
 Threads (1-16 threads supported)
*****************************************************************************************

 Threads   VP ratios (1/n = once per n isr cycles)   Recommended
     1     1/1                                           yes
     2     1/1, 1/2                                      yes
     3     1/1, 1/3                                      yes
     4     1/1, 1,2, 1/4                                 yes
     5     1/1, 1/5                                      no
     6     1/1, 1/2, 1/3, 1/6                            yes
     7     1/1, 1/7                                      no
     8     1/1, 1/2, 1/4, 1/8                            yes
     9     1/1, 1/3, 1/9                                 no
    10     1/1, 1/2, 1/5, 1/10                           no
    11     1/1, 1/11                                     no
    12     1/1, 1/2, 1/3, 1/4, 1/6, 1/12                 yes
    13     1/1, 1/13                                     no
    14     1/1, 1/2, 1/7, 1/14                           no
    15     1/1, 1/3, 1/5, 1/15                           no
    16     1/1, 1/2, 1/4, 1/8, 1/16                      yes
*/

#define Baud_divide(baud,ratio)  ((2 * uartfs / baud / ratio) + 1) / 2

#pragma library 0
#endif
// End of file vpobjDefs.h
