// File cstring.h for CC1B
#ifndef _CSTRING_H_
#define _CSTRING_H_
//include other libraries here
#include <memory.h>
#include <string.h>
#pragma library 1

char *cstrcat(char *s, const char *t);
const char *cstrchr(const char *s, char c);
int cstrcmp(char *s, const char *t);
char *cstrcpy(char *s, const char *t);
long cstrlen(const char *s);
char *cstrncat(char *s, const char *t, int n);
int cstrncmp(char *s, const char *t, int n);
char *cstrncpy(char *s, const char *t, int n);
const char *cstrrchr(const char *s, char c);

/**
 * concatenate t to end of s 
 * s must be large enough
 */
char *cstrcat(char *s, const char *t) {
  char *d = s + strlen(s);
  char temp;
  while (*t) {
    temp = *t;
	*d = temp;
	d++;
	t++;
  }
  *d = 0;
  return (s);
}

/**
 * return pointer to 1st occurrence of c in s, else 0
 */
const char *cstrchr(const char *s, char c) {
  while (*s) {
    if (*s == c) return (s);
    ++s;
  }
  return (0);
}

/**
 * return <0,   0,  >0 according to s<t, s=t, s>t
 */
int cstrcmp(char *s, const char *t) {
  char result;
  _SystemTemp = *t;
  while (*s == _SystemTemp) {
    if (*s == 0) {
 	  return (0);
    }
	++s;
	++t;
	_SystemTemp = *t;
  }
  result = *s - _SystemTemp;
  return (result);
}

/**
 * copy t to s 
 */
char *cstrcpy(char *s, const char *t) {
  char *d = s;
  //char temp;
  while (*t) {
    _SystemTemp = *t;
	*d = _SystemTemp;
	d++;
	t++;
  }
  *d = 0;
  return (s);
}

/**
 * return length of string s
 */
long cstrlen(const char *s) {
  long n = 0;
  while (*s) {
    s++;
    n++;
  }
  return (n);
}

/**
 * concatenate n bytes max from t to end of s 
 * s must be large enough
 */
char *cstrncat(char *s, const char *t, int n) {
  char *d = s + strlen(s);
  char temp;
  while (n) {
    n--;
    if (*t) {
	  temp = *t;
	  *d = temp;
	  d++;
	  t++;
    }
	else break;
  }
  *d = 0;
  return (s);
}

/**
 * strncmp(s,t,n) - Compares two strings for at most n
 *                  characters and returns an integer
 *                  >0, =0, or <0 as s is >t, =t, or <t.
 */
int cstrncmp(char *s, const char *t, int n) {
  char temp;
  while (n) {
    n--;
    temp = *t;
    if (*s == temp) {
      if (*s == 0) return (0);
      ++s;
	  ++t;
    }
  }
  if (n) return (*s - *t);
  return (0);
}

/**
 * copy n characters from t to s (null padding)
 */
char *cstrncpy(char *s, const char *t, int n) {
  char *d = s;
  char temp;
  while (n > 0) {
    n--;
	if (*t) {
      temp = *t;
	  *d = temp;
	  d++;
	  t++;
	  continue;
	}
    while (n > 0) {
	  n--;
	  *d = 0;
	  d++;
    }
	return (s);
  }
  *d = 0;
  return (s);
}

/**
 * Search s for rightmost occurrance of c.
 * s = Pointer to string to be searched.
 * c = Character to search for.
 * Returns pointer to rightmost c or NULL.
 */
const char *cstrrchr(const char *s, char c) {
  const char *ptr = 0;
  while (*s) {
    if (*s == c) ptr = s;
    ++s;
  }
  return (ptr);
}

#pragma library 0
#endif
// End of file cstring.h
