// File memory.h for CC1B
#ifndef _MEMORY_H_
#define _MEMORY_H_
//include other libraries here
#pragma library 1

shadowDef char _SystemRam[256] @0x00;
char _MainTemp @0x0E; //used as temporary placeholder for mainlevel code
char _IsrTemp @0x0D; //used as temporary placeholder for isr code
char _IsrBank @0x0C; //holds rambank for interrupt code
char _TaskTemp @0x0B; //used as temporary placeholder for tasklevel code

//save register M during interrupt
#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_
char _IsrMode @0xF8; //same as DDRDCOPY, but SX48/52 save M automatically during interrupt in shadow register
#endif

//runtime DDR registers
char DDRACOPY @0xF5;
char DDRBCOPY @0xF6;
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_
char DDRCCOPY @0xF7;
#endif
#if defined _CHIP_SX48_ || defined _CHIP_SX52_
char DDRDCOPY @0xF8;
char DDRECOPY @0xF9;
#endif

/**
 * Initializes DDR copy registers to 0xFF (same as chip DDR registers)
 */
void DDR_init() {
  W = 255;
  DDRACOPY = W;
  DDRBCOPY = W;
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_
  DDRCCOPY = W;
#endif
#if defined _CHIP_SX48_ || defined _CHIP_SX52_
  DDRDCOPY = W;
  DDRECOPY = W;
#endif
}

#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_

/**
 * Calculate physical ram address from logical _SystemRam array index (0-143)
 * logical -> physical
 * 0x00-0x0F -> 0x00-0x0F
 * 0x10-0x1F -> 0x10-0x1F
 * 0x20-0x2F -> 0x30-0x3F
 * 0x30-0x3F -> 0x50-0x5F
 * 0x40-0x4F -> 0x70-0x7F
 * 0x50-0x5F -> 0x90-0x9F
 * 0x60-0x6F -> 0xB0-0xBF
 * 0x70-0x7F -> 0xD0-0xDF
 * 0x80-0x8F -> 0xF0-0xFF
 *
 * @param index Logical index into _SystemRam array
 * @return physical ram address
 */
char _SystemRamAddress(char index) {
  W &= 0xF0;
  if (!Zero_) {
    index += W;
    index -= 0x10;
  }
  return index;
}

/**
 * Calculate logical _SystemRam array index (0-143) from physical ram address
 * physical -> logical
 * 0x00-0x0F -> 0x00-0x0F
 * 0x10-0x1F -> 0x10-0x1F
 * 0x30-0x3F -> 0x20-0x2F
 * 0x50-0x5F -> 0x30-0x3F
 * 0x70-0x7F -> 0x40-0x4F
 * 0x90-0x9F -> 0x50-0x5F
 * 0xB0-0xBF -> 0x60-0x6F
 * 0xD0-0xDF -> 0x70-0x7F
 * 0xF0-0xFF -> 0x80-0x8F
 *
 * @param addr Physical ram address
 * @return logical index into _SystemRam array
 */
char _SystemRamIndex(char addr) {
  if (addr.4) {
    addr.4 = 0;
	W &= 0x0F;
    addr += W;
    addr = (addr >> 1) + 0x10;
  }
  return addr;
}

/**
 * Write value to large array
 * example: LargeArrayWrite(&myArray[0],index,value);
 *
 * @param base Physical ram address (>=0x10) of array element 0
 * @param index Logical index into array
 * @param value Value to write
 */
#define LargeArrayWrite(base,index,value) \
  _MainTemp = value; \
  W = index; \
  FSR = W; \
  W &= 0xF0; \
  FSR += W; \
  W = base; \
  FSR += W; \
  FSR.4 = 1; \
  INDF = _MainTemp;
  
/**
 * Read value from large array
 * example: LargeArrayRead(&myArray[0],index);
 *                 value = W;
 *
 * @param base Physical ram address (>= 0x10) of array element 0
 * @param index Logical index into array
 * @return value
 */
#define LargeArrayRead(base,index) \
  W = index; \
  FSR = W; \
  W &= 0xF0; \
  FSR += W; \
  W = base; \
  FSR += W; \
  FSR.4 = 1; \
  W = INDF;
  
/**
 * Calculate physical ram address from array index
 *
 * @param base Physical ram address of array element 0
 * @param index Logical index into array
 * @return Physical ram address of array element index
 */
char LargeArrayAddress(char base, char index) {
  return _SystemRamAddress(_SystemRamIndex(base)+index);
}

/**
 * Calculate array index from physical ram address
 *
 * @param base Physical ram address of array element 0
 * @param addr Physical ram address of array element index
 * @return Logical index into array
 */
char LargeArrayIndex(char base, char addr) {
  addr = _SystemRamIndex(addr);
  return addr - _SystemRamIndex(base);
}

#endif

#if defined _CHIP_SX48_ || defined _CHIP_SX52_

/**
 * Calculate physical ram address from logical _SystemRam array index (0-255)
 * logical -> physical
 * 0x00-0xFF -> 0x00-0xFF
 *
 * @param index Logical index into _SystemRam array
 * @return physical ram address
 */
char _SystemRamAddress(char index) {
  return index;
}

/**
 * Calculate logical _SystemRam array index (0-255) from physical ram address
 * physical -> logical
 * 0x00-0xFF -> 0x00-0xFF
 *
 * @param addr Physical ram address
 * @return logical index into _SystemRam array
 */
char _SystemRamIndex(char addr) {
  return addr;
}

/**
 * Write value to large array
 * example: LargeArrayWrite(&myArray[0],index,value);
 *
 * @param base Physical ram address (>=0x10) of array element 0
 * @param index Logical index into array
 * @param value Value to write
 */
#define LargeArrayWrite(base,index,value) \
  _MainTemp = value; \
  W = index; \
  FSR = W; \
  W = base; \
  FSR += W; \
  INDF = _MainTemp;
  
/**
 * Read value from large array
 * example: LargeArrayRead(&myArray[0],index);
 *                 value = W;
 *
 * @param base Physical ram address (>= 0x10) of array element 0
 * @param index Logical index into array
 * @return value
 */
#define LargeArrayRead(base,index) \
  W = index; \
  FSR = W; \
  W = base; \
  FSR += W; \
  W = INDF;
  
/**
 * Calculate physical ram address from array index
 *
 * @param base Physical ram address of array element 0
 * @param index Logical index into array
 * @return Physical ram address of array element index
 */
char LargeArrayAddress(char base, char index) {
  return base + index;
}

/**
 * Calculate array index from physical ram address
 *
 * @param base Physical ram address of array element 0
 * @param addr Physical ram address of array element index
 * @return Logical index into array
 */
char LargeArrayIndex(char base, char addr) {
  return addr - base;
}

#endif

/**
 * Read word from codepage (rom)
 *
 * @param addr Physical rom address
 *                        SX18/20/28: 0x000-0x7FF
 *                        SX48/52: 0x000-0xFFF
 * @return Word (12bits) at addr
 */
long RomWord(long addr) {
  MODE = addr.high8;
  W = addr.low8;
  iread();
  addr.low8 = W;
  addr.high8 = MODE;
  return addr;
}

/**
 * Read char from codepage (rom)
 *
 * @param addr Physical rom address
 *                        SX18/20/28: 0x000-0x7FF
 *                        SX48/52: 0x000-0xFFF
 * @return Char (8bits) at addr
 */
char RomChar(long addr) {
  MODE = addr.high8;
  W = addr.low8;
  iread();
  return W;
}

/**
 * Copy chars from codepage (rom) to ram
 *
 * @param dest Physical ram address
 * @param source Physical rom address
 *                            SX18/20/28: 0x000-0x7FF
 *                            SX48/52: 0x000-0xFFF
 * @param len Number of bytes to copy
 */
void RomCopy(char dest, long source, char len) {
  char i = 0;
  while (len > 0) {
    _MainTemp = RomChar(source);
	char k = LargeArrayAddress(dest,i);
	_SystemRam[k] = _MainTemp;
	source++;
	i++;
	len--;
  }
}

#pragma library 0
#endif
// End of file memory.h
