// File string.h for CC1B
#ifndef _STRING_H_
#define _STRING_H_
//include other libraries here
#include <memory.h>
#pragma library 1

char *strcat(char *s, char *t);
char *strchr(char *s, char c);
int strcmp(char *s, char *t);
char *strcpy(char *s, char *t);
int strlen(char *s);
char *strncat(char *s, char *t, int n);
int strncmp(char *s, char *t, int n);
char *strncpy(char *s, char *t, int n);
char *strrchr(char *s, char c);

/**
 * concatenate t to end of s 
 * s must be large enough
 */
char *strcat(char *s, char *t) {
  char *d = s + strlen(s);
  //char temp;
  while (*t) {
    _SystemTemp = *t;
	*d = _SystemTemp;
	d++;
	t++;
  }
  *d = 0;
  return (s);
}

/**
 * return pointer to 1st occurrence of c in s, else 0
 */
char *strchr(char *s, char c) {
  while (*s) {
    if (*s == c) return (s);
    ++s;
  }
  return (0);
}

/**
 * return <0,   0,  >0 according to s<t, s=t, s>t
 */
int strcmp(char *s, char *t) {
  char result;
  _SystemTemp = *t;
  while (*s == _SystemTemp) {
    if (*s == 0) {
	  return (0);
	}
    ++s;
	++t;
	_SystemTemp = *t;
  }
  result = *s - _SystemTemp;
  return (result);
}

/**
 * copy t to s 
 */
char *strcpy(char *s, char *t) {
  char *d = s;
  //char temp;
  while (*t) {
    _SystemTemp = *t;
	*d = _SystemTemp;
	d++;
	t++;
  }
  *d = 0;
  return (s);
}

/**
 * return length of string s
 */
int strlen(char *s) {
  char n = 0;
  while (*s) {
    s++;
    n++;
  }
  return (n);
}

/**
 * concatenate n bytes max from t to end of s 
 * s must be large enough
 */
char *strncat(char *s, char *t, int n) {
  char *d = s + strlen(s);
  char temp;
  while (n) {
    n--;
    if (*t) {
	  temp = *t;
	  *d = temp;
	  d++;
	  t++;
    }
	else break;
  }
  *d = 0;
  return (s);
}

/**
 * strncmp(s,t,n) - Compares two strings for at most n
 *                  characters and returns an integer
 *                  >0, =0, or <0 as s is >t, =t, or <t.
 */
int strncmp(char *s, char *t, int n) {
  char temp;
  while (n) {
    n--;
    temp = *t;
    if (*s == temp) {
      if (*s == 0) return (0);
      ++s;
	  ++t;
    }
  }
  if (n) return (*s - *t);
  return (0);
}

/**
 * copy n characters from t to s (null padding)
 */
char *strncpy(char *s, char *t, int n) {
  char *d = s;
  char temp;
  while (n > 0) {
    n--;
	if (*t) {
      temp = *t;
	  *d = temp;
	  d++;
	  t++;
	  continue;
	}
    while (n > 0) {
	  n--;
	  *d = 0;
	  d++;
    }
	return (s);
  }
  *d = 0;
  return (s);
}

/**
 * Search s for rightmost occurrance of c.
 * s = Pointer to string to be searched.
 * c = Character to search for.
 * Returns pointer to rightmost c or NULL.
 */
char *strrchr(char *s, char c) {
  char *ptr = 0;
  while (*s) {
    if (*s == c) ptr = s;
    ++s;
  }
  return (ptr);
}

#pragma library 0
#endif
// End of file string.h
