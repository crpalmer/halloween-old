// File objQueue.h for CC1B
#ifndef _OBJQUEUE_H_
#define _OBJQUEUE_H_
//include other libraries here
#include <memory.h>
#pragma library 1

/**
 * This library provides a queue object that can store up to 14 bytes. The queue must reside in a single rambank.
 * The functions are writton so that they can be used in any call tree (interrupt, mainlevel and tasklevel)
 *
 * Any char array can be initialized to be a queue
 * char q[12];
 * _MainTemp = 8; \\size of the queue must be stored in a global ram location
 * objQueue_init(q,_MainTemp);
 * This declares q[0]-q[7] to be a queue that has a total size of 8 bytes (6 bytes data + 2 bytes overhead)
 *
 * Values are stored into the queue by using function objQueue_enqueue.
 * It requires the value to be enqueued to be stored in a global ram location before calling.
 * if (!objQueue_full(q)) {
 *   _MainTemp = value; //value to enqueu must be in a global ram location
 *   objQueue_enqueue(q,_MainTemp);
 * }
 * The function can be used in any call tree by using either _MainTemp, _IsrTemp or _TaskTemp as the global ram location.
 *
 * Values are retrieved from the queue using function objQueue_dequeue.
 * This function returns true if the value is retrieved, or false if the queue is empty
 * The retrieved value is returned in W
 * if (objQueue_dequeue(q) {
 *   value = W;
 * }
 *
 * The queue can be cleared by using the function objQueue_clear(q)
 * To test if the queue is empty, use objQueue_isEmpty(q)
 * To test if the queue is full, use objQueue_isFull(q)
 */

//queue buffer layout
//
// +----+----+
// |size| num|  size = number of databytes in queue buffer, num = number of values in queue 
// +----+----+
// |head|tail|  head = position last stored value, tail = position before value to retrieve
// +----+----+
// | d a t a |
// | d a t a |

/** Initialize a queue
 * How to use:
 *   char q[12];
 *   _MainTemp = 12; //size of queue must be in a global ram location
 *   objQueue_init(q,_MainTemp);
 *
 * @param queue Queue address
 * @param size Size of the queue. The size MUST have been stored in a global ram location (0x00-0x0F)
 *                        Valid range for size is 3 to 16. Queue capacity is size-2.
 */
#define objQueue_init(queue,size) \
{ \
  W = queue; \
#pragma update_FSR 0 \
  FSR = W; \
  size--; \
  size--; \
  W = swap(size); \
  INDF = W; \
  FSR++; \
  INDF = 0; \
#pragma update_FSR 1 \
}

/** Check if queue is empty
 *
 * @param W Queue address
 * @return True if queue empty, false if not empty
 */
bit objQueue_isEmpty(char W) {
#pragma update_FSR 0
  FSR = W;
  W = 0x0F;
  W &= INDF; //extract num
#pragma update_FSR 1
  return Zero_;
}

/** Check if queue is full
 *
 * @param W Queue address
 * @return True if queue full, false if not full
 */
bit objQueue_isFull(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF);
  W ^= INDF; //xor num with size
#pragma update_FSR 1
  return Zero_;
}

/** Clear queue
 *
 * @param W Queue address
 */
void objQueue_clear(char W) {
#pragma update_FSR 0
  FSR = W;
  W = 0xF0;
  INDF &= W;  //clear num
  FSR++;
  INDF = 0; //clear headtail
#pragma update_FSR 1
}

/** Get number of stored bytes in queue
 *
 * @param W Queue address
 * @return number of stored bytes (0 to queuesize-2)
 */
char objQueue_length(char W) {
#pragma update_FSR 0
  FSR = W;
  W = INDF; //get num in lownib
  W &= 0x0F;
#pragma update_FSR 1
  return W;
}

/** Get capacity of queue
 *
 * @param W Queue address
 * @return capacity of queue (maximum 14)
 */
char objQueue_capacity(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF); //get size in lownib
  W &= 0x0F;
#pragma update_FSR 1
  return W;
}

/** Get size of queue
 *
 * @param W Queue address
 * @return size of queue (maximum 16)
 */
char objQueue_size(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF); //get size in lownib
  W &= 0x0F;
  FSR = 0;
  FSR.1 = 1;  //FSR=2 (overhead)
  W += FSR; //get total queue size
#pragma update_FSR 1
  return W;
}

/** Get number of free bytes in queue
 *
 * @param W Queue address
 * @return number of free bytes (0 to queuesize-2)
 */
char objQueue_free(char W) {
#pragma update_FSR 0              //example:
  FSR = W;                        // INDF = 0101_0010 = size_num  size-num = 5-2=3
  W = swap(INDF); //get size in lownib         // W       = 0010_0101
  W = INDF - W;                   // W       = 0010_1101
  W &= 0x0F;                      // W       = 0000_1101  W=13
  FSR = 0;                        // FSR    = 0
  FSR.4 = 1;                      // FSR    = 16
  W = FSR - W;                    // W       = 16-13 = 3
#pragma update_FSR 1
  return W;
}

/** Enqueue value into queue
 * How to use:
 * if (!objQueue_isFull(q)) {
 *   _MainTemp = value; //value to enqueu must be in a global ram location
 *   objQueue_enqueue(q,_MainTemp);
 * }
 *
 * @param queue Queue address
 * @param value Value to write. The value MUST have been stored in a global ram location (0x00-0x0F)
 */
#define objQueue_enqueue(queue,value) \
{ \
  FSR = _objQueue_enqueueAddress(queue); \
  INDF = value; \
}

/** INTERNAL FUNCTION: Check if a queue can accept a new value and adjust pointers if so.
 * This function should not be called directly, but only from the macro objQueue_enqueue.
 * This function adjusts the queue's head pointer and num field if the queue is not full.
 * So if the queue is not full, a new value MUST be stored in the queue.
 *
 * @param W Queue address
 * @return enqueue address (if queue was not full)
 */
char _objQueue_enqueueAddress(char W) {
#pragma update_FSR 0
  FSR = W;
  W = swap(INDF);
  W ^= INDF; // xor size with num
  if (!Zero_) {
    INDF++; //inc num
    FSR++;
    INDF += 0x10; //inc head
    FSR--;
    W = INDF; //get size
    FSR++;
    W ^= INDF; //xor size with head
    W &= 0xF0;
    W = 0x0F;
    if (Zero_) INDF &= W; //if head == size then clear head
    W = swap(INDF); //get head in lownib
    W &= 0x0F;
    FSR++; //point to queue data begin
    W += FSR; //head position
  }
#pragma update_FSR 1
  return W;
}

/** Dequeue value from queue
 * How to use:
 * if (!objQueue_isEmpty(q)) {
 *   value = objQueue_dequeue(q);
 * }
 *
 * @param W Queue address
 * @return Value from queue (if queue was not empty)
 */
char objQueue_dequeue(char W) {
#pragma update_FSR 0
  FSR = W;
  W = INDF; //load size+num
  W &= 0x0F; //test num
  if (!Zero_) {
    INDF--; //dec num
	W = swap(INDF); //get size in lownib
	FSR++;
	INDF++; //inc tail
	W ^= INDF; //xor size with tail
	W &= 0x0F;
	W = 0xF0;
	if (Zero_) INDF &= W; //if tail == size then clear tail
	W = INDF; //get tail in lownib
	W &= 0x0F;
	FSR++; //point to queue data begin
	FSR += W; //tail position
	W = INDF; //get value
  }
#pragma update_FSR 1
  return W;
}

#pragma library 0
#endif
// End of file objQueue.h
