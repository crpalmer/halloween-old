// File Portpin.h for CC1B
#ifndef _PORTPIN_H_
#define _PORTPIN_H_
//include other libraries here
#pragma library 1

/**
 * This library contains functions to manipulate port and pin levels and directions via variables.
 * (For fixed pins and ports, use ports and pins directly, eg. RA = 0x12, RA.3 = 1).
 * The functions are mostly macros. All functions can be used in any call tree (interrupt, mainlevel and tasklevel).
 * Some functions require that a parameter is stored in a global ram location before calling.
 *    For mainlevel code, use _MainTemp
 *    For TASK subroutines, use _TaskTemp
 *    For interrupt code, use _IsrTemp
 * The proper way in case of such a parameter is:
 *   _MainTemp = parameter;
 *   someFunction(port,_MainTemp);
 * See the function descriptions for details.
 */

// port functions

/**
 * Update DDR register
 * This function writes the DDR copy register for the specified port to the appropiate chip DDR register.
 * It is used by the pin and port direction functions.
 * This function prevents possible glitches on port pins (in case the interrupt routine also accesses the DDR registers),
 * by inserting a few NOPs when a RTCC rollover interrupt would occur between reading the DDR copy register
 * and updating the chip DDR register.
 *
 * @param W Port identifier PORT_RA to PORT_RE
 *                     It is also possible to use the highbyte of a portpin value, eg. PORTPIN_RA3>>8
 */
void DDR_update(char W) {
  W &= 0x0F;
  switch (W) { //update correct DDR register without possible glitches due to interrupt
    case PORT_RA:
#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_
                  W = 0xF8;
#endif
#if defined _CHIP_SX48_ || defined _CHIP_SX52_
                  W = 0xF7;
#endif
                  W = RTCC - W; //if RTCC != W at start of this instruction, then 4 clock ticks
	              if (Zero_) { //else 5 clock ticks, so interrupt occurs before MOV W,DDRACOPY
	                nop();
	                nop();
	                nop();
	              }
	              DDRA = DDRACOPY;
                  break;
    case PORT_RB:
#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_
                  W = 0xF8;
#endif
#if defined _CHIP_SX48_ || defined _CHIP_SX52_
                  W = 0xF7;
#endif
                  W = RTCC - W;
	              if (Zero_) {
	                nop();
	                nop();
	                nop();
	              }
	              DDRB = DDRBCOPY;
                  break;
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_
    case PORT_RC:
#if defined _CHIP_SX28_
                  W = 0xF8;
#endif
#if defined _CHIP_SX48_ || defined _CHIP_SX52_
                  W = 0xF7;
#endif
                  W = RTCC - W;
	              if (Zero_) {
	                nop();
	                nop();
	                nop();
	              }
	              DDRC = DDRCCOPY;
                  break;
#endif
#if defined _CHIP_SX48_ || defined _CHIP_SX52_
    case PORT_RD:
                  W = 0xF7;
                  W = RTCC - W;
	              if (Zero_) {
	                nop();
	                nop();
	                nop();
	              }
	              DDRD = DDRDCOPY;
                  break;
    case PORT_RE:
                  W = 0xF7;
                  W = RTCC - W;
	              if (Zero_) {
	                nop();
	                nop();
	                nop();
	              }
	              DDRE = DDRECOPY;
                  break;
#endif
  }
}

/**
 * Write port direction register
 * This function writes a value to the port direction register.
 * The port latch register is not changed.
 * A '1' in the value specifies an input pin, a '0' specifies an output pin.
 * The value to write MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = direction;
 * writePortDirection(port,_MainTemp);
 *
 * @param port Identifier for port which direction register to write
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param direction Bits specify direction for corresponding pins
 *                                 0 = output, 1 = input
 */
#define writePortDirection(port,direction) \
{ \
  W = (port) | 0xF0; \
#pragma update_FSR 0 \
  FSR = W; \
  W = direction; \
  INDF = W; \
#pragma update_FSR 1 \
  DDR_update(port); \
}

/**
 * Read port direction register
 * This function reads the direction register of the specified port (actually its shadow register).
 * A '1' in the value specifies an input pin, a '0' specifies an output pin.
 * How to use:
 * direction = readPortDirection(port);
 *
 * @param W Identifier for port which direction register to read
 *                     You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @return direction Bits specify direction for corresponding pins
 *                                 0 = output, 1 = input
 */
char readPortDirection(char W) {
  W |= 0xF0;
#pragma update_FSR 0
  FSR = W;
  W = INDF; //get DDRACOPY to DDRECOPY
#pragma update_FSR 1
  return W;
}

/**
 * Write port latch register.
 * This function writes a value to the port latch register.
 * The port direction register is not changed.
 * A '1' in the value specifies a high pin output level, a '0' specifies a low pin output level.
 * The value to write MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = value;
 * writePortLatch(port,_MainTemp);
 *
 * @param port Identifier for port which latch to write
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param value Bits specify output level for corresponding pins
 *                          0 = low, 1 = high
 */
#define writePortLatch(port,value) \
{ \
  W = port & 0x0F; \
#pragma update_FSR 0 \
  FSR = W; \
  W = value; \
  INDF = W; \
#pragma update_FSR 1 \
}

/**
 * Read port.
 * This function reads the levels at the port pins (it does not read the port latch register).
 * A '1' in the value specifies a high level, a '0' specifies a low level.
 * How to use:
 * value = readPort(port);
 *
 * @param W Identifier for port which pins to read
 *                     You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @return value Bits specify levels at corresponding pins
 *                          0 = low, 1 = high
 */
char readPort(char W) {
  W &= 0x0F;
#pragma update_FSR 0
  FSR = W;
  W = INDF; //read value
#pragma update_FSR 1
  return W;
}

/**
 * Set port level
 * This function writes a value to the port level register.
 * A '1' in the value specifies TTL pin level, a '0' specifies CMOS pin level.
 * The value to write MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = level;
 * setPortLevel(port,_MainTemp);
 *
 * @param port Identifier for port which level register to write
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param level Bits specify cmos (2.5V) or ttl (1.4V) level for corresponding pins
 *                         0 = cmos, 1 = ttl
 */
#define setPortLevel(port,level) \
{ \
  switch ((port) & 0xF0) { \
    case PORT_RA: LVL_A = level; \
	              break; \
    case PORT_RB: LVL_B = level; \
	              break; \
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_ \
    case PORT_RC: LVL_C = level; \
	              break; \
#endif \
#if defined _CHIP_SX48_ || defined _CHIP_SX52_ \
    case PORT_RD: LVL_D = level; \
	              break; \
    case PORT_RE: LVL_E = level; \
	              break; \
#endif \
  } \
}

/**
 * Set port pullup
 * This function writes a value to the port pullup register.
 * A '1' in the value specifies no pullup, a '0' specifies pullup enabled.
 * The value to write MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = pullup;
 * setPortPullup(port,_MainTemp);
 *
 * @param port Identifier for port which level register to write
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pullup Bits specify internal pullup resistors setting for corresponding pins
 *                           0 = enabled, 1 = disabled
 */
#define setPortPullup(port,pullup) \
{ \
  switch ((port) & 0xF0) { \
    case PORT_RA: PLP_A = pullup; \
	              break; \
    case PORT_RB: PLP_B = pullup; \
	              break; \
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_ \
    case PORT_RC: PLP_C = pullup; \
	              break; \
#endif \
#if defined _CHIP_SX48_ || defined _CHIP_SX52_ \
    case PORT_RD: PLP_D = pullup; \
	              break; \
    case PORT_RE: PLP_E = pullup; \
	              break; \
#endif \
  } \
}

/**
 * Set port schmitt trigger
 * This function writes a value to the port schmitt-trigger register.
 * A '1' in the value specifies no schmitt-trigger input, a '0' specifies schmitt-trigger input enabled.
 * The value to write MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = trigger;
 * setPortSchmittTrigger(port,_MainTemp);
 *
 * @param port Identifier for port which level register to write
 *                        You can use PORT_RB to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RB3>>8) 
 * @param trigger Bits specify schmitt trigger inputs setting for corresponding pins
 *                             0 = enabled, 1 = disabled
 */
#define setPortSchmittTrigger(port,trigger) \
{ \
  switch ((port) & 0xF0) { \
    case PORT_RB: ST_B = trigger; \
	              break; \
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_ \
    case PORT_RC: ST_C = trigger; \
	              break; \
#endif \
#if defined _CHIP_SX48_ || defined _CHIP_SX52_ \
    case PORT_RD: ST_D = trigger; \
	              break; \
    case PORT_RE: ST_E = trigger; \
	              break; \
#endif \
  } \
}

// pin functions

/**
 * Make specified port pins output.
 * This function clears specified bits in DDRACOPY to DDRECOPY and then updates the appropiate DDR register.
 * The port latch registers are not changed.
 * A '1' in the pinmask specifies the corresponding pin must be set to output.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = pinmask;
 * setPinOutput(port,_MainTemp);
 *
 * @param port Identifier for port which pins must be made outputs
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which pin or pins to make outputs
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define setPinOutput(port,pinmask) \
{ \
  W = (port) | 0xF0; \
#pragma update_FSR 0 \
  FSR = W; \
  W = ~pinmask; \
  INDF &= W; \
#pragma update_FSR 1 \
  DDR_update(port); \
}

/**
 * Make specified port pins input.
 * This function sets specified bits in DDRACOPY to DDRECOPY and then updates the appropiate DDR register.
 * The port latch registers are not changed.
 * A '1' in the pinmask specifies the corresponding pin must be set to input.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = pinmask;
 * setPinInput(port,_MainTemp);
 *
 * @param port Identifier for port which pins must be made inputs
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which pin or pins to make inputs
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define setPinInput(port,pinmask) \
{ \
  W = (port) | 0xF0; \
#pragma update_FSR 0 \
  FSR = W; \
  W = pinmask; \
  INDF |= W; \
#pragma update_FSR 1 \
  DDR_update(port); \
}

/**
 * Make specified port pins low.
 * This function clears specified bits in the port latch register.
 * The port direction registers are not changed.
 * A '1' in the pinmask specifies the corresponding latch register bit must be cleared.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = pinmask;
 * setPinLow(port,_MainTemp);
 *
 * @param port Identifier for port which pins must be cleared
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which latch register bits to clear
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define setPinLow(port,pinmask) \
{ \
  W = (port) & 0x0F; \
#pragma update_FSR 0 \
  FSR = W; \
  W = ~pinmask; \
  INDF &= W; \
#pragma update_FSR 1 \
}

/**
 * Make specified port pins high.
 * This function sets specified bits in the port latch register.
 * The port direction registers are not changed.
 * A '1' in the pinmask specifies the corresponding latch register bit must be set.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = pinmask;
 * setPinHigh(port,_MainTemp);
 *
 * @param port Identifier for port which pins must be set
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which latch register bits to set
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define setPinHigh(port,pinmask) \
{ \
  W = (port) & 0x0F; \
#pragma update_FSR 0 \
  FSR = W; \
  W = pinmask; \
  INDF |= W; \
#pragma update_FSR 1 \
}

/**
 * Make specified port pins low or high.
 * This function sets or clears specified bits in the port latch register.
 * The port direction registers are not changed.
 * A '1' in the pinmask specifies the corresponding latch register bit must be set or cleared.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * The carry value specifies wether latch register bits are set or cleared.
 * How to use:
 * Carry = level; //0=low, 1=high
 * _MainTemp = pinmask;
 * writePin(port,_MainTemp);
 *
 * @param port Identifier for port which pins must be set or cleared
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which latch register bits to set or clear (determined by carry)
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define writePinLatch(port,pinmask) \
{ \
  if (Carry) { \
    setPinHigh(port,pinmask); \
  } \
  else { \
    setPinLow(port,pinmask); \
  } \
}

/**
 * Read pin.
 * This function reads the specified port input pins (it does not read specified port latch register bits).
 * A '1' in the pinmask specifies the corresponding pins must be extracted.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * If a single pin is specified, the Zero_ flag identifies the inverted pin input level
 * If multiple pins are specified, W identifies which pins have a high input.
 * How to use:
 * _MainTemp = pinmask;
 * readPin(port,_MainTemp);
 * pinlevel = !Zero_; //0=low 1=high
 *
 * @param port Identifier for port which pins must be set
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which pin to read
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 * @return level at pin input 0 for low, 1 for high
 */
#define readPin(port,pinmask) \
{ \
  W = readPort(port); \
  W &= pinmask; \
}

/**
 * Read pin direction
 * This function reads specified bits of the direction register of the specified port (actually its shadow register).
 * A '1' in the pinmask specifies the corresponding pins must be extracted.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * If a single pin is specified, the Zero_ flag identifies the inverted pin direction.
 * If multiple pins are specified, W identifies which pins are inputs.
 * How to use:
 * _MainTemp = pinmask;
 * readPinDirection(port,_MainTemp);
 * pindirection = !Zero_; //0=output 1=input
 *
 * @param port Identifier for port which pin direction must be read
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which pin direction to read
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 * @return direction Specifies direction for pin 0 = output, 1 = input
 */
#define readPinDirection(port,pinmask) \
{ \
  W = readPortDirection(port); \
  W &= pinmask; \
}

/**
 * Write pin direction.
 * This function sets or clears specified bits in DDRACOPY to DDRECOPY and then updates the appropiate DDR register.
 * The port latch registers are not changed.
 * A '1' in the pinmask specifies the corresponding direction register bit must be set or cleared.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * The carry value specifies wether direction register bits are set or cleared.
 * How to use:
 * Carry = direction; //0=output, 1=input
 * _MainTemp = pinmask;
 * writePinDirection(port,_MainTemp);
 *
 * @param port Identifier for port which pin direction must be read
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which pin direction to write
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define writePinDirection(port,pinmask) \
{ \
  if (Carry) { \
    setPinInput(port,pinmask); \
  } \
  else { \
    setPinOutput(port,pinmask); \
  } \
}

/**
 * Toggle pin direction.
 * This function inverts the specified bits of the port direction register.
 * The port latch registers are not changed.
 * A '1' in the pinmask specifies the corresponding direction register bit that must be inverted.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = pinmask;
 * togglePinDirection(port,_MainTemp);
 *
 * @param port Identifier for port which pin direction bits must be inverted
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which direction register bits to invert
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define togglePinDirection(port,pinmask) \
{ \
  W = readPortDirection(port); \
  pinmask ^= W; \
  writePortDirection(port,pinmask); \
}

/**
 * Toggle pin.
 * This function writes the inverted input pin levels to the port latch register.
 * The port direction registers are not changed.
 * A '1' in the pinmask specifies the corresponding latch register bit that must be written.
 * The pinmask MUST be stored in a global ram location before calling this function.
 * How to use:
 * _MainTemp = pinmask;
 * togglePin(port,_MainTemp);
 *
 * @param port Identifier for port which latch register bits must be written with the inverted input level
 *                        You can use PORT_RA to PORT_RE or the highbyte of a portpin value or portpin constant (PORTPIN_RA3>>8) 
 * @param pinmask Specifies which latch register bits to write
 *                             A single pin can be specified, eg. PORTPIN_RA0, or an ORed combination
 *                             eg. PORTPIN_RB0 | PORTPIN_RB2 | PORTPIN_RB7 or PORTPIN_RB for all pins
 */
#define togglePin(port,pinmask) \
{ \
  W = readPort(port); \
  pinmask ^= W; \
  writePortLatch(port,pinmask); \
}

#pragma library 0
#endif
// End of file Portpin.h
