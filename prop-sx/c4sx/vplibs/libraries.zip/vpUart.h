// File vpUart.h for CC1B
#ifndef _VPUART_H_
#define _VPUART_H_
//include other libraries here
#include <memory.h>
#pragma library 1

#define vpUartRx(name,datapin,dataconfig,hspin,hsconfig,baud,ratio,format) \
#ifndef vpUartRx_installed \
#define vpUartRx_installed \
#endif \
#if (Baud_divide(baud,ratio) < 2) || (Baud_divide(baud,ratio) > 170) \
#error Specified baudrate not possible with supplied ratio \
#endif \
#pragma cdata. ##name = VP_UARTRX,16 \
#if (hspin != 0) \
#ifndef vpUartRx_hs \
#define vpUartRx_hs \
#endif \
#if (hspin & PORTPIN_OC) != 0 \
#ifndef vpUartRx_hoc \
#define vpUartRx_hoc \
#endif \
#endif \
#pragma cdata[] = ((datapin)>>8)|0x80 \
#else \
#pragma cdata[] = (datapin)>>8 \
#endif \
#pragma cdata[] = (datapin)&0xFF,Baud_divide(baud,ratio),format,0,0,0,0 \
#if (hspin != 0) \
#pragma cdata[] = (hspin)>>8,(hspin)&0xFF, 0x40 \
#else \
#pragma cdata[] = 0x60,0,0 \
#endif \
#pragma cdata[] = 0,0,0,0,0 \
#pragma cdata. ##name##_pinconfig \
#if (datapin != 0) && (dataconfig != 0) \
#pragma cdata[] = (datapin)>>8,(datapin)&0xFF,dataconfig \
#endif \
#if (hspin != 0) && (hsconfig != 0) \
#pragma cdata[] = (hspin)>>8,(hspin)&0xFF,hsconfig \
#endif \
#pragma cdata[] = 0

#define vpUartTx(name,datapin,dataconfig,hspin,hsconfig,baud,ratio,format) \
#ifndef vpUartTx_installed \
#define vpUartTx_installed \
#endif \
#if (Baud_divide(baud,ratio) < 2) || (Baud_divide(baud,ratio) > 170) \
#error Specified baudrate not possible with supplied ratio \
#endif \
#if (datapin & PORTPIN_OC) != 0 \
#ifndef vpUartTx_doc \
#define vpUartTx_doc \
#endif \
#endif \
#pragma cdata. ##name = VP_UARTTX,16 \
#if (hspin != 0) \
#ifndef vpUartTx_hs \
#define vpUartTx_hs \
#endif \
#pragma cdata[] = ((datapin)>>8)|0x80 \
#else \
#pragma cdata[] = (datapin)>>8 \
#endif \
#pragma cdata[] = (datapin)&0xFF,Baud_divide(baud,ratio),format,0,0,0,0 \
#if (hspin != 0) \
#pragma cdata[] = (hspin)>>8,(hspin)&0xFF, 0x40 \
#else \
#pragma cdata[] = 0x60,0,0 \
#endif \
#pragma cdata[] = 0,0,0,0,0 \
#pragma cdata. ##name##_pinconfig \
#if (datapin != 0) && (dataconfig != 0) \
#pragma cdata[] = (datapin)>>8,(datapin)&0xFF,dataconfig \
#endif \
#if (hspin != 0) && (hsconfig != 0) \
#pragma cdata[] = (hspin)>>8,(hspin)&0xFF,hsconfig \
#endif \
#pragma cdata[] = 0

shadowDef char vpUart_dport @0x10; //data port - lownib=5(RA) to 9(RE)
  shadowDef bit vpUart_dinvert @0x10.4; //invert
  shadowDef bit vpUart_docmode @0x10.5; //opencollector
  shadowDef bit vpUart_dinput @0x10.6; //datapin input placeholder
  shadowDef bit vpUart_handshake @0x10.7; //set if handshake pin used
shadowDef char vpUart_dpin @0x11; //pin bitmask (specified bit set , other bits cleared)
shadowDef char vpUart_baud @0x12; //baudrate
shadowDef char vpUart_format @0x13; //
  shadowDef bit vpUart_bits0 @0x13.0; //total bits: 01=9 10=10 11=11
  shadowDef bit vpUart_bits1 @0x13.1; //
  shadowDef bit vpUart_7bits @0x13.2; //set for 7 databits (0 = 8 databits)
  shadowDef bit vpUart_even @0x13.3; //set for even parity
  shadowDef bit vpUart_odd @0x13.4; //set for odd parity
  shadowDef bit vpUart_data @0x13.5; //set if valid value, cleared after value grabbed
  shadowDef bit vpUart_error @0x13.6; //set if parity error
  shadowDef bit vpUart_parity @0x13.7; //parity bit placeholder
shadowDef char vpUart_count @0x14; //number of bits
shadowDef char vpUart_divide @0x15; //timing counter
shadowDef char vpUart_low @0x16; //shift register
shadowDef char vpUart_high @0x17; //value
shadowDef char vpUart_hport @0x18; //handshake port - lownib=5(RA) to 9(RE) (optional queue if handshake not used)
  shadowDef bit vpUart_hinvert @0x18.4; //invert
  shadowDef bit vpUart_hocmode @0x18.5; //opencollector
  shadowDef bit vpUart_hinput @0x10.6; //handshake pin input placeholder
  shadowDef bit vpUart_hlevel @0x18.7; //logical handshake pin output level
shadowDef char vpUart_hpin @0x19; //pin bitmask (specified bit set , other bits cleared)
shadowDef char vpUart_buf[6] @0x1A; //optional queue

/**
 * Isr code for virtual peripheral receive uart
 * This part only receives the serial bits.
 */
#define vpUartRx_ISR \
{ \
#pragma update_FSR 0 \
  FSR = _IsrBank; \
  W = vpUart_dport & 0x0F; \
  FSR = W; \
  _IsrTemp = INDF; \
  FSR = _IsrBank; \
  W = _IsrTemp; \
  if (vpUart_dinvert) W ^= vpUart_dpin; \
  W &= vpUart_dpin; \
  Carry = 1; \
  if (Zero_) Carry = 0; \
  vpUart_dinput = Carry; \
  if (!vpUart_count) { \
    if (!Carry) { \
	  W = vpUart_format-1; \
	  W &= 0x03; \
	  W |= 0x08; \
      vpUart_count = W; \
    } \
	W = vpUart_baud >> 1; \
	W += vpUart_baud; \
    vpUart_divide = W; \
  } \
  vpUart_divide--; \
  if (!vpUart_divide) { \
    vpUart_count--; \
    if (vpUart_count > 0) { \
	  Carry = vpUart_dinput; \
      vpUart_low = rr(vpUart_low); \
      vpUart_parity = Carry; \
    } \
    else { \
      W = vpUart_low; \
      vpUart_high = W; \
      vpUart_data = 1; \
    } \
#ifdef vpUartRx_hs \
    if (vpUart_handshake) { \
      if (vpUart_hlevel) { \
        W = ~vpUart_hpin; \
	    _IsrTemp = W; \
	    W = vpUart_hport & 0x0F; \
	    if (vpUart_hocmode) W |= 0xF0; \
	    FSR = W; \
	    W = _IsrTemp; \
	    INDF &= W; \
      } \
	  else { \
        W = vpUart_hpin; \
	    _IsrTemp = W; \
	    W = vpUart_hport & 0x0F; \
#ifdef vpUartRx_hoc \
	    if (vpUart_hocmode) W |= 0xF0; \
#endif \
	    FSR = W; \
	    W = _IsrTemp; \
	    INDF |= W; \
	  } \
      W = _IsrBank; \
      FSR = W; \
#ifdef vpUartRx_hoc \
      if (vpUart_hocmode) { \
	    vpUart_divide = MODE; \
	    W = vpUart_hport | 0xF0; \
	    FSR = W; \
#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_ \
		W = 0x0F; \
#endif \
#if defined _CHIP_SX48_ || defined _CHIP_SX52_ \
		W = 0x1F; \
#endif \
        MODE = W; \
	    W = FSR & 0x0F; \
	    switch (W) { \
          case PORT_RA: W = DDRACOPY; \
		                controlA(W); \
	                    break; \
          case PORT_RB: W = DDRBCOPY; \
		                controlB(W); \
		                break; \
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_ \
		  case PORT_RC: W = DDRCCOPY; \
		                controlC(W); \
		                break; \
#endif \
#if defined _CHIP_SX48_ || defined _CHIP_SX52_ \
          case PORT_RD: W = DDRDCOPY; \
		                controlD(W); \
		                break; \
          case PORT_RE: W = DDRECOPY; \
		                controlE(W); \
		                break; \
#endif \
	    } \
        W = _IsrBank; \
        FSR = W; \
	    MODE = vpUart_divide; \
	  } \
#endif \
    } \
#endif \
    vpUart_divide = vpUart_baud; \
  } \
#pragma update_FSR 1 \
}

/**
 * Isr code for virtual peripheral transmit uart
 * This part only transmits the serial bits.
 */
#define vpUartTx_ISR \
{ \
#pragma update_FSR 0 \
  FSR = _IsrBank; \
  vpUart_divide--; \
  if (!vpUart_divide) { \
    if (vpUart_count) { \
      Carry = 0; \
	  if (vpUart_dinvert) Carry = 1; \
      vpUart_high = rr(vpUart_high); \
      vpUart_low = rr(vpUart_low); \
      vpUart_count--; \
	  if (!vpUart_count) vpUart_data = 0; \
      if (vpUart_low.5) { \
        W = ~vpUart_dpin; \
	    _IsrTemp = W; \
	    W = vpUart_dport & 0x0F; \
#ifdef vpUartTx_doc \
	    if (vpUart_docmode) W |= 0xF0; \
#endif \
	    FSR = W; \
		W = _IsrTemp; \
		INDF &= W; \
      } \
	  else { \
        W = vpUart_dpin; \
	    _IsrTemp = W; \
	    W = vpUart_dport & 0x0F; \
	    if (vpUart_docmode) W |= 0xF0; \
	    FSR = W; \
		W = _IsrTemp; \
		INDF |= W; \
	  } \
      W = _IsrBank; \
      FSR = W; \
#ifdef vpUartTx_doc \
      if (vpUart_docmode) { \
		vpUart_divide = MODE; \
	    W = vpUart_dport | 0xF0; \
		FSR = W; \
#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_ \
		W = 0x0F; \
#endif \
#if defined _CHIP_SX48_ || defined _CHIP_SX52_ \
		W = 0x1F; \
#endif \
        MODE = W; \
		W = FSR & 0x0F; \
		switch (W) { \
          case PORT_RA: W = DDRACOPY; \
		                controlA(W); \
		                break; \
          case PORT_RB: W = DDRBCOPY; \
		                controlB(W); \
		                break; \
#if defined _CHIP_SX28_ || defined _CHIP_SX48_ || defined _CHIP_SX52_ \
		  case PORT_RC: W = DDRCCOPY; \
		                controlC(W); \
		                break; \
#endif \
#if defined _CHIP_SX48_ || defined _CHIP_SX52_ \
          case PORT_RD: W = DDRDCOPY; \
		                controlD(W); \
		                break; \
          case PORT_RE: W = DDRECOPY; \
		                controlE(W); \
		                break; \
#endif \
		} \
        W = _IsrBank; \
        FSR = W; \
		MODE = vpUart_divide; \
	  } \
#endif \
    } \
    vpUart_divide = vpUart_baud; \
#ifdef vpUartTx_hs \
    if (vpUart_handshake) { \
      W = vpUart_hport & 0x0F; \
      FSR = W; \
      _IsrTemp = INDF; \
      FSR = _IsrBank; \
      W = _IsrTemp; \
      if (vpUart_hinvert) W ^= vpUart_hpin; \
      W &= vpUart_hpin; \
      vpUart_hinput = 1; \
      if (Zero_) vpUart_hinput = 0; \
    } \
#endif \
  } \
#pragma update_FSR 1 \
}

/**
 * Check if byte available
 *
 * @param W vpUart address
 * @return True if byte available
 */
bit vpUartRx_byteAvailable(char W) {
#pragma update_FSR 0
  FSR = W;
  if (vpUart_data) return 1;
#pragma update_FSR 1
  return 0;
}

/**
 * Post-isr code for virtual peripheral receive uart
 * This function grabs a received byte and checks for parity error if required.
 * How to use:
 * if (vpUartRx_byteAvailable(rx)) {
 *    value = vpUartRx_receiveByte(rx);
 * }
 *
 * @param W vpUart address
 * @return received byte
 */
char vpUartRx_receiveByte(char W) {
#pragma update_FSR 0
  FSR = W;
  Carry = vpUart_parity; //get last saved b0
  if (vpUart_format.1) goto uit1;
  Carry = 0; //adjust for 7 databits + no parity (total 9 bits)
  vpUart_high = rr(vpUart_high);
  vpUart_high = rr(vpUart_high);
uit1:
  if (vpUart_format.0) vpUart_high = rl(vpUart_high); //adjust for 8 databits + parity (total 11 bits)
  if (!vpUart_7bits) goto uit2;
  Carry = vpUart_high.7; //save possible parity in case 7 databits
  vpUart_high.7 = 0; //clear b7 in case 7 databits
uit2:
  vpUart_parity = Carry; //save possible paritybit
  W = vpUart_high;
  vpUart_low = W;
  //calculate parity
  W = swap(vpUart_low); //_low = abcdefgh
  vpUart_low ^= W;
  W = vpUart_low >> 1;
  vpUart_low ^= W;
  // at this point, the parity for half the bits (a,b,e,f) is in bit 2 of _low, and the
  // parity for the other half (c,d,g,h) is in bit 0 of _low.
  //	if the parity of (a,b,e,f) is 0, then the parity of (a,b,c,d,e,f,g,h)
  // is equal to the parity of (c,d,g,h)... which is already in bit 0, so skip ahead.
  if (vpUart_low.2) {
    // otherwise, the parity of (a,b,e,f) is 1, so the parity of (a,b,c,d,e,f,g,h) is
    // NOT equal to the parity of (c,d,g,h)... invert bit 0.
    vpUart_low++;
  }
  // at this point, bit 0 contains the parity of (a,b,c,d,e,f,g,h).
  vpUart_error = 0;
  W = vpUart_format & 0x18; //extract odd and even bits
  if (!Zero_) {
    if (vpUart_odd) vpUart_low++; //invert calculated paritybit for odd parity
    vpUart_low += vpUart_parity; //if parity matches, b0 will be cleared
    vpUart_error = vpUart_low.0;
  }
  vpUart_data = 0; //mark byte grabbed
  W = vpUart_high;
#pragma update_FSR 1
  return W;
}

/**
 * Post-isr code for virtual peripheral receive uart
 * This function returns the errorbit that is updated by vpUartRx_receiveByte()
 * so it should be called after vpUartRx_receiveByte() is called (only when parity is used).
 *
 * @param W vpUart address
 * @return errorbit updated by vpUartRx_receiveByte()
 */
bit vpUartRx_parityError(char W) {
#pragma update_FSR 0
  FSR = W;
  Carry = vpUart_error; //get error bit
#pragma update_FSR 1
  return Carry;
}

/**
 * Post-isr code for virtual peripheral receive uart
 * This function turns the handshake output pin (RTS) on (remote sender may transmit) or off
 * The carry must be set to turn RTS on, and clear to turn RTS off
 *
 * @param W vpUart address
 */
void vpUartRx_RTSonoff(char W) {
  FSR = W;
#pragma update_FSR 0
  if (vpUart_handshake) {
    vpUart_hlevel = Carry;
  }
#pragma update_FSR 1
}

/**
 * Post-isr code for virtual peripheral receive uart
 * This function turns the optional handshake output pin (RTS) on (remote sender may transmit)
 *
 * @param W vpUart address
 */
void vpUartRx_RTSon(char W) {
  FSR = W;
#pragma update_FSR 0
  if (vpUart_handshake) {
    vpUart_hlevel = 1;
  }
#pragma update_FSR 1
}

/**
 * Post-isr code for virtual peripheral receive uart
 * This function turns the optional handshake output pin (RTS) off (remote sender may not transmit)
 *
 * @param W vpUart address
 */
void vpUartRx_RTSoff(char W) {
  FSR = W;
#pragma update_FSR 0
  if (vpUart_handshake) {
    vpUart_hlevel = 0;
  }
#pragma update_FSR 1
}

/**
 * Pre-isr code for virtual peripheral transmit uart
 * This part checks if the transmitter is idle and the optional handshake input pin (CTS) allows sending.
 *
 * @param W vpUart address
 * @return True if CTS is on or no handshake is used AND the transmitter is idle (transmitting allowed)
 */
bit vpUartTx_ready(char W) {
  FSR = W;
#pragma update_FSR 0
  if (vpUart_data) return 0; //transmitter busy
  if (!vpUart_handshake) return 1; //no handshake
  Carry = vpUart_hinput; //current logical CTS input level (1 if transmitting allowed)
#pragma update_FSR 1
  return Carry;
}

/** Write value to vpUart transmitter
 * How to use:
 * if (vpUartTx_ready(tx)) {
 *   _MainTemp = value; //value to write must be in a global ram location
 *   vpUartTx_sendByte(tx,_MainTemp);
 * }
 *
 * @param queue Physical address of queue
 * @param value Value to write. The value MUST have been stored in a global ram location (0x00-0x0F)
 */
#define vpUartTx_sendByte(uart,value) \
{ \
  FSR = uart; \
#pragma update_FSR 0 \
  vpUart_high = ~value; \
#pragma update_FSR 1 \
  _vpUartTx_sendByte(uart); \
}

/**
 * INTERNAL FUNCTION: Pre-isr code for virtual peripheral transmit uart
 * This function calculates parity if required and sets up the transmitter for an outgoing byte.
 * Do not call this function directly but call the macro vpUartTx_sendByte().
 *
 * @param W vpUart address
 */
void _vpUartTx_sendByte(char W) {
  FSR = W;
#pragma update_FSR 0
  if (vpUart_7bits) vpUart_high.7 = 0; //if not 8 bits then clear b7 for parity calculation (also stopbit)
  //calculate inverted even parity
  W = vpUart_high;
  vpUart_low = W;
  W = swap(vpUart_low); //_low = abcdefgh
  vpUart_low ^= W;
  W = vpUart_low >> 1;
  vpUart_low ^= W;
  // at this point, the even parity for half the bits (a,b,e,f) is in bit 2 of _low, and the
  // even parity for the other half (c,d,g,h) is in bit 0 of _low.
  //	if the even parity of (a,b,e,f) is 0, then the parity of (a,b,c,d,e,f,g,h)
  // is equal to the even parity of (c,d,g,h)... but we want the inverted even parity.
  if (!vpUart_low.2) {
    vpUart_low++;
  }
  vpUart_low = rr(vpUart_low);
  // at this point, carry contains the inverted even parity of (a,b,c,d,e,f,g,h).
  if (vpUart_odd) goto uot1;
  if (!vpUart_even) goto uot2;
    Carry = !Carry; //invert paritybit
uot1:
  if (!vpUart_7bits) goto uot3;
  vpUart_high.7 = Carry; //if 7 databits then move parity into b7
uot2:
  Carry = 0; //ready stopbit
uot3:
  vpUart_low.7 = 1; //setup startbit
  vpUart_high = rr(vpUart_high); //rotate in paritybit or stopbit
  vpUart_low = rr(vpUart_low);
  W = vpUart_format; //get total number of bits (start+data+parity+stop)
  W &= 0x03; //1, 2 or 3
  W |= 0x08; //9, 10 or 11
  vpUart_data = 1; //mark transmitter busy
  vpUart_count = W; //now uart vp starts to transmit
#pragma update_FSR 1
}

/**
 * Get address of vpUart queue
 *
 * @param W vpUart address
 * @return address of queue
 */
char vpUart_queue(char W) {
#pragma update_FSR 0
  W &= 0xF0;
  W |= 0x08; //((&vpUart_hport) & 0x0F);
  FSR = W;
  if (vpUart_handshake) {
    FSR++;
	FSR++;
  }
#pragma update_FSR 1
  return FSR;
}

#pragma library 0
#endif
// End of file vpUart.h
