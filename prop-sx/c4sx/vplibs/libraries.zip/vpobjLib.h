// File vpobjLib.h for CC1B

/*
	This library requires the following constants to be defined before including the library
	
	#define  VPSLOTS  4     //set number of VP slots (SX18/20/28: 1 to 6, SX48/52: 1 to 8)
	#define  VPRAM  0x50  //set first vp ram bank
*/

#ifndef _VPOBJLIB_H_
#define _VPOBJLIB_H_
//include other libraries here
#pragma library 1

#ifndef VPSLOTS
#error VPSLOTS must be defined before including <vpobjLib.h>
#endif
#ifndef VPRAM
#error VPRAM must be defined before including <vpobjLib.h>
#endif

#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_
#define vpobjLib_vpRambank(index) \
#if index == 0 \
#define VPBANK0 (VPRAM+0x00) \
#elif index == 1 \
#define VPBANK1 (VPRAM+0x20) \
#elif index == 2 \
#define VPBANK2 (VPRAM+0x40) \
#elif index == 3 \
#define VPBANK3 (VPRAM+0x60) \
#elif index == 4 \
#define VPBANK4 (VPRAM+0x80) \
#elif index == 5 \
#define VPBANK5 (VPRAM+0xA0) \
#endif \
char vpBank##index[16] @(VPRAM+(index<<5));
#endif

#if defined _CHIP_SX48_ || defined _CHIP_SX52_
#define vpobjLib_vpRambank(index) \
#if index == 0 \
#define VPBANK0 (VPRAM+0x00) \
#elif index == 1 \
#define VPBANK1 (VPRAM+0x10) \
#elif index == 2 \
#define VPBANK2 (VPRAM+0x20) \
#elif index == 3 \
#define VPBANK3 (VPRAM+0x30) \
#elif index == 4 \
#define VPBANK4 (VPRAM+0x40) \
#elif index == 5 \
#define VPBANK5 (VPRAM+0x50) \
#elif index == 6 \
#define VPBANK6 (VPRAM+0x60) \
#elif index == 7 \
#define VPBANK7 (VPRAM+0x70) \
#elif index == 8 \
#define VPBANK8 (VPRAM+0x70) \
#endif \
char vpBank##index[16] @(VPRAM+(index<<4));
#endif

#if VPSLOTS >= 0
vpobjLib_vpRambank(0)
#endif
#if VPSLOTS >= 1
vpobjLib_vpRambank(1)
#endif
#if VPSLOTS >= 2
vpobjLib_vpRambank(2)
#endif
#if VPSLOTS >= 3
vpobjLib_vpRambank(3)
#endif
#if VPSLOTS >= 4
vpobjLib_vpRambank(4)
#endif
#if VPSLOTS >= 5
vpobjLib_vpRambank(5)
#endif
#if VPSLOTS >= 6
vpobjLib_vpRambank(6)
#endif
#if VPSLOTS >= 7
vpobjLib_vpRambank(7)
#endif
#if VPSLOTS >= 8
vpobjLib_vpRambank(8)
#endif

/**
 * vpListType array holds  entries of vp type identifying data
 * vpListDefs array holds offset to label VPDEFINITIONS
 * vpList index number specifies rambank: 0 ->first vp object,VPSLOTS-1 -> last vp object
 * a vpListType entry value of 0 specifies a free entry
*/
#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_
#define VPLIST (VPRAM + (VPSLOTS<<5))
#endif
#if defined _CHIP_SX48_ || defined _CHIP_SX52_
#define VPLIST (VPRAM + (VPSLOTS<<4))
#endif

shadowDef char vpListType[VPSLOTS] @VPLIST;
shadowDef char vpListDefs[VPSLOTS] @VPLIST + VPSLOTS;

/**
 * Initialize VP environment
 * This function must be called prior to any other function from this library.
 */
void vpInit() {
  char i;
  for (i=0; i<VPSLOTS; i++) {
    vpListType[i] = 0;
  }
}

/**
 * Setup pins for virtual peripheral. Do not call this function directly from the application code.
 * The virtual peripheral pin setup data is stored in rom at the passed address
 * This data consists of 3 byte records identifying pins and configuration.
 * If the first byte of this record is 0 then there are no more pins to setup.
 *
 * @param addr Address of virtual peripheral pin setup data
 * @param install 1 to setup pin after intall, 0 to setup pin after uninstall
 */
void _vpPinSetup(long addr, char install) {
  char port, pinmask, pinconfig;
  while (1) {
    port = RomChar(addr);
	if (!port) return;
	addr++;
	pinmask = RomChar(addr);
	addr++;
	pinconfig = RomChar(addr); //pinconfig
	if (install) pinconfig = swap(pinconfig);
	if (pinconfig.2) {
	  _MainTemp = pinmask;
	  if (pinconfig.1) {
	    setPinInput(port,_MainTemp);
	  }
	  if (pinconfig.0) {
	    setPinHigh(port,_MainTemp);
	  }
	  else {
	    setPinLow(port,_MainTemp);
	  }
	  if (!pinconfig.1) {
	    setPinOutput(port,_MainTemp);
	  }
	}
    addr++;
  }
}

/**
 * Install virtual peripheral.
 * This function installs a virtual peripheral in the first available vp rambank.
 * If all vp slots are occupied, this function returns 0.
 *
 * @param addr Address of virtual peripheral initialization data
 * @return handle for installed virtual peripheral if succesful, or 0 if not succesful
 *                The format of the handle: high nibble (b7-b4) are bits b7-b4 of rambank where virtual peripheral is installed
 *                                                            low nibble (b3-b0) are the index in the vpListType array
 */
char vpInstall(long addr) {
  char i,len;
  for (i=0; i<VPSLOTS; i++) {
    if (vpListType[i] == 0) {
      _MainTemp = (char)(addr - VPDEFINITIONS);
	  vpListDefs[i] = _MainTemp;
	  _MainTemp = RomChar(addr);
	  vpListType[i] = _MainTemp;
      len = i << 4;
#if defined _CHIP_SX18_ || defined _CHIP_SX20_ || defined _CHIP_SX28_
      len <<= 1;
#endif
      len += VPRAM;
	  i += len; //rambank in high nibble, index in low nibble
      addr++;
      len = RomChar(addr);
      addr++;
      RomCopy(i & 0xF0,addr,len);
	  addr += len; //point to pinconfig
      _vpPinSetup(addr,1);
	  return i;
	}
  }
  return 0;
}

/**
 * Uninstall virtual peripheral.
 * This function removes the installed VP from the vpList.
 * The handle should be considered invalid after using this function.
 *
 * @param bnk Handle of installed VP
 */
void vpUninstall(char bnk) {
  bnk &= 0x0F;
  if (vpListType[bnk] != 0) {
    long addr = vpListDefs[bnk];
	addr += VPDEFINITIONS;
    vpListType[bnk] = 0;
    addr++;
    _vpPinSetup(addr,0);
  }
}

#pragma library 0
#endif
// End of file vpobjLib.h
